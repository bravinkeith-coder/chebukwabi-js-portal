import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Activity, BarChart3, CalendarDays, ChevronDown, Crosshair, Gauge, Heart, Home, LayoutDashboard, MapPin, NotebookPen, Plus, RefreshCcw, Search, Shield, Shuffle, Swords, Target, Trash2, TrendingUp, Users, Zap, Trophy, Megaphone, ClipboardCheck, Sparkles, Phone, Mail, CheckCircle2, Languages, ArrowRight, Coins, HandCoins } from 'lucide-react';

type Section = 'Home' | 'Boys' | 'Girls' | 'Fixtures' | 'Tactical' | 'Analysis' | 'News' | 'Join' | 'Donate' | 'Portal';
type Role = 'Coach' | 'Player' | 'Parent' | null;
type PortalTab = 'Dashboard' | 'Squad' | 'Attendance' | 'Notes' | 'My Profile' | 'Training' | 'Announcements' | 'Fixtures' | 'News' | 'Team Photos';
type FormationKey = '4-3-3' | '4-4-2' | '3-5-2' | '4-2-3-1';
type TeamKey = 'Boys' | 'Girls';
type Player = { id:number; name:string; team:string; pos:string; num:number; grade:string; rating:number; goals:number; assists:number; xg:number; pass:number; pace:number; passing:number; shooting:number; defending:number; dribbling:number; color:string; note?:string };
type SavedPlayer = { id:string; name:string; pos:string; num:number; grade:string; note:string; team:string };
type SavedNote = { id:string; kind:string; title:string; body:string };
type Lang = 'en' | 'sw';
type Match = { id:string; team:TeamKey; home:string; away:string; shortH:string; shortA:string; homeColor:string; awayColor:string; score:string; status:string; comp:string; date:string; venue:string; poss:[number,number]; xg:[number,number]; shots:[number,number]; onTarget:[number,number]; passes:[number,number]; passAcc:[number,number]; corners:[number,number]; fouls:[number,number]; momentum:number[]; formH:string[]; formA:string[]; motm:string; verdict:string; moments:{min:string; type:string; label:string; team:string; color:string}[] };

const CJS = 'Chebukwabi JS';
const season = { played:12, won:8, drawn:3, lost:1, gf:29, ga:11, position:'2nd', topScorer:'Emmanuel Khaemba — 11 goals', cleanSheets:6 };
const lastFive = [
  { opp:'Kibachenje JS', score:'2 — 1', result:'W', where:'Home' },
  { opp:'Webuye DEB JS', score:'0 — 0', result:'D', where:'Away' },
  { opp:'Khasoko JS', score:'4 — 1', result:'W', where:'Home' },
  { opp:'Bumula JS', score:'1 — 1', result:'D', where:'Away' },
  { opp:'Mungore JS', score:'2 — 0', result:'W', where:'Home' },
];
const nextMatch = { opp:'Namwela JS', date:'SAT • 10:00', venue:'Chebukwabi JS Ground', comp:'Sub-County School Games', note:'Focus: quick wide play, protect the space behind the full-backs.' };
const lastResult = { opp:'Kibachenje JS', score:'2 — 1', comp:'Sub-County School Games', scorers:'Khaemba • Wanyonyi', note:'Strong second half. The press created both goals.' };

const boysFixtures = [
  { date:'Sat 14 Jun • 10:00', opp:'Namwela JS', venue:'Chebukwabi JS Ground', comp:'Bungoma Sub-County Games', note:'Season opener at home — arrive 9:15.' },
  { date:'Sat 21 Jun • 10:00', opp:'Mungore JS', venue:'Mungore JS Ground', comp:'Bungoma Sub-County Games', note:'Away day. Team bus leaves 8:00.' },
  { date:'Sat 28 Jun • 10:00', opp:'Bumula JS', venue:'Chebukwabi JS Ground', comp:'Bungoma Sub-County Games', note:'Home fixture. Green & gold day.' },
  { date:'Sat 05 Jul • 10:00', opp:'Kibachenje JS', venue:'Kibachenje JS Ground', comp:'Bungoma Sub-County Games', note:'Big away test against the leaders.' },
  { date:'Sat 12 Jul • 14:00', opp:'Webuye DEB JS', venue:'Chebukwabi JS Ground', comp:'Friendly', note:'Friendly — all squad players get minutes.' },
];
const girlsFixtures = [
  { date:'Sat 14 Jun • 08:30', opp:'Namwela Girls JS', venue:'Chebukwabi JS Ground', comp:'Bungoma Sub-County Games', note:'Girls kick off the double-header at home.' },
  { date:'Sat 21 Jun • 08:30', opp:'Mungore Girls JS', venue:'Mungore JS Ground', comp:'Bungoma Sub-County Games', note:'Away day with the boys’ squad.' },
  { date:'Sat 28 Jun • 08:30', opp:'Khasoko Girls JS', venue:'Chebukwabi JS Ground', comp:'Bungoma Sub-County Games', note:'Home fixture. Come early and support.' },
  { date:'Sat 05 Jul • 08:30', opp:'Bumula Girls JS', venue:'Bumula JS Ground', comp:'Bungoma Sub-County Games', note:'Away fixture — same bus, same team spirit.' },
  { date:'Sat 12 Jul • 12:00', opp:'Webuye DEB Girls JS', venue:'Chebukwabi JS Ground', comp:'Friendly', note:'Friendly — every player gets game time.' },
];

const boysMatches: Match[] = [
  { id:'B-CJS-NAM', team:'Boys', home:'Chebukwabi JS', away:'Namwela JS', shortH:'CJS', shortA:'NAM', homeColor:'#0A5C36', awayColor:'#b91c1c', score:'3 — 1', status:'FULL TIME', comp:'Bungoma Sub-County Games', date:'SAT 10:00', venue:'Chebukwabi JS Ground', poss:[58,42], xg:[2.41,0.92], shots:[15,8], onTarget:[7,3], passes:[412,318], passAcc:[87,79], corners:[7,3], fouls:[11,14], momentum:[18,34,48,55,62,58,71,66,78,82,88,84], formH:['W','D','W','D','W'], formA:['W','L','D','W','L'], motm:'Emmanuel Khaemba — 2 goals, constant threat in behind', verdict:'The game turned on midfield control and the timing of the changes. Chebukwabi attacked the half-space more often in the final 25 minutes.',
    moments:[{min:"14'", type:'Goal', label:'Khaemba opens the scoring after a cut-back', team:'CJS', color:'#FFC107'},{min:"31'", type:'Card', label:'Yellow for a tactical foul in midfield', team:'NAM', color:'#fff'},{min:"52'", type:'Goal', label:'Namwela level from a set-piece', team:'NAM', color:'#FFC107'},{min:"68'", type:'Sub', label:'Fresh legs on the wing — tempo lift', team:'CJS', color:'#6ec7ff'},{min:"79'", type:'Goal', label:'Late winner from the edge of the box', team:'CJS', color:'#FFC107'}] },
  { id:'B-CJS-MUN', team:'Boys', home:'Chebukwabi JS', away:'Mungore JS', shortH:'CJS', shortA:'MUN', homeColor:'#0A5C36', awayColor:'#1d4ed8', score:'2 — 0', status:'FULL TIME', comp:'Bungoma Sub-County Games', date:'SAT 10:00', venue:'Chebukwabi JS Ground', poss:[55,45], xg:[1.86,0.64], shots:[13,7], onTarget:[5,2], passes:[398,341], passAcc:[84,78], corners:[6,3], fouls:[12,15], momentum:[42,50,58,62,55,68,72,76,80,84,88,90], formH:['W','W','D','W','W'], formA:['L','W','D','L','W'], motm:'Austin Barasa — controlled the tempo and created 4 chances', verdict:'Clean sheet built on a compact midfield and brave defending at set-pieces. The second goal came from a patient build-up.',
    moments:[{min:"22'", type:'Goal', label:'Header from a well-worked corner', team:'CJS', color:'#FFC107'},{min:"41'", type:'Card', label:'Yellow for dissent after a foul', team:'MUN', color:'#fff'},{min:"66'", type:'Sub', label:'Mungore bring on a striker', team:'MUN', color:'#6ec7ff'},{min:"81'", type:'Goal', label:'Sealed on the break, composure in the box', team:'CJS', color:'#FFC107'}] },
  { id:'B-BUM-CJS', team:'Boys', home:'Bumula JS', away:'Chebukwabi JS', shortH:'BUM', shortA:'CJS', homeColor:'#7c3aed', awayColor:'#0A5C36', score:'1 — 1', status:'FULL TIME', comp:'Bungoma Sub-County Games', date:'SAT 10:00', venue:'Bumula JS Ground', poss:[48,52], xg:[1.05,1.42], shots:[9,12], onTarget:[4,5], passes:[352,389], passAcc:[81,84], corners:[4,6], fouls:[14,11], momentum:[44,50,46,58,54,48,58,62,56,64,60,58], formH:['D','W','L','D','W'], formA:['W','D','W','D','W'], motm:'Ian Wanjala — captain’s performance at the back', verdict:'A fair point away from home. We must be braver in the final third and sharper at the far post on corners.',
    moments:[{min:"19'", type:'Goal', label:'Bumula strike first from the press', team:'BUM', color:'#FFC107'},{min:"38'", type:'Card', label:'Booking for stopping a break', team:'CJS', color:'#fff'},{min:"59'", type:'Sub', label:'Double change to add width', team:'CJS', color:'#6ec7ff'},{min:"74'", type:'Goal', label:'Chebukwabi equalise against the run of play', team:'CJS', color:'#FFC107'}] },
];
const girlsMatches: Match[] = [
  { id:'G-CJS-NAM', team:'Girls', home:'Chebukwabi JS Girls', away:'Namwela Girls JS', shortH:'CJS', shortA:'NAM', homeColor:'#0A5C36', awayColor:'#b91c1c', score:'2 — 0', status:'FULL TIME', comp:'Bungoma Sub-County Games', date:'SAT 08:30', venue:'Chebukwabi JS Ground', poss:[57,43], xg:[1.92,0.68], shots:[14,6], onTarget:[6,2], passes:[386,302], passAcc:[86,77], corners:[6,2], fouls:[10,13], momentum:[48,56,62,58,68,72,66,78,84,88,82,90], formH:['W','W','D','W','W'], formA:['W','L','W','D','L'], motm:'Faith Chebet — 2 goals and relentless pressing', verdict:'A mature performance. The girls kept the ball, pressed in pairs, and defended the box with real discipline.',
    moments:[{min:"18'", type:'Goal', label:'Chebet finishes a quick wide combination', team:'CJS', color:'#FFC107'},{min:"36'", type:'Card', label:'Yellow for a late challenge', team:'NAM', color:'#fff'},{min:"61'", type:'Sub', label:'Fresh legs on the left wing', team:'CJS', color:'#6ec7ff'},{min:"74'", type:'Goal', label:'Second goal on the counter — calm finish', team:'CJS', color:'#FFC107'}] },
  { id:'G-CJS-KHA', team:'Girls', home:'Chebukwabi JS Girls', away:'Khasoko Girls JS', shortH:'CJS', shortA:'KHA', homeColor:'#0A5C36', awayColor:'#ea580c', score:'3 — 1', status:'FULL TIME', comp:'Bungoma Sub-County Games', date:'SAT 08:30', venue:'Chebukwabi JS Ground', poss:[60,40], xg:[2.68,0.94], shots:[16,7], onTarget:[8,3], passes:[418,288], passAcc:[88,76], corners:[7,2], fouls:[9,12], momentum:[52,60,68,64,74,70,82,78,88,92,86,94], formH:['W','W','W','D','W'], formA:['L','W','L','W','D'], motm:'Mercy Achieng — hat-trick of chances created, 1 goal', verdict:'The best attacking display of the season so far. Wide play and early crosses caused problems all game.',
    moments:[{min:"9'", type:'Goal', label:'Early breakthrough on the counter', team:'CJS', color:'#FFC107'},{min:"27'", type:'Goal', label:'Second from a set-piece routine', team:'CJS', color:'#FFC107'},{min:"55'", type:'Goal', label:'Khasoko pull one back', team:'KHA', color:'#FFC107'},{min:"82'", type:'Goal', label:'Third in transition — 3v2 executed', team:'CJS', color:'#FFC107'}] },
  { id:'G-BUM-CJS', team:'Girls', home:'Bumula Girls JS', away:'Chebukwabi JS Girls', shortH:'BUM', shortA:'CJS', homeColor:'#7c3aed', awayColor:'#0A5C36', score:'1 — 1', status:'FULL TIME', comp:'Bungoma Sub-County Games', date:'SAT 08:30', venue:'Bumula JS Ground', poss:[49,51], xg:[1.10,1.55], shots:[10,12], onTarget:[4,5], passes:[348,392], passAcc:[81,84], corners:[4,6], fouls:[13,11], momentum:[46,52,48,58,54,50,60,64,58,66,62,60], formH:['D','W','L','D','W'], formA:['W','D','W','D','W'], motm:'Grace Wanjiru — captain, led the comeback', verdict:'Character to come back away from home. Next step: start faster and win more second balls in midfield.',
    moments:[{min:"21'", type:'Goal', label:'Bumula strike first from the press', team:'BUM', color:'#FFC107'},{min:"58'", type:'Sub', label:'Double change to add width', team:'CJS', color:'#6ec7ff'},{min:"76'", type:'Goal', label:'Chebukwabi equalise late — captain’s header', team:'CJS', color:'#FFC107'}] },
];
const allMatches = [...boysMatches, ...girlsMatches];

const basePlayers: Player[] = [
  { id:1, name:'Brian Wekesa', team:CJS, pos:'GK', num:1, grade:'Grade 9', rating:8.2, goals:0, assists:0, xg:0, pass:82, pace:68, passing:78, shooting:38, defending:82, dribbling:62, color:'#0A5C36', note:'Safe hands • Commands the box' },
  { id:2, name:'Collins Simiyu', team:CJS, pos:'DF', num:2, grade:'Grade 9', rating:8.0, goals:1, assists:4, xg:0.8, pass:84, pace:82, passing:80, shooting:58, defending:84, dribbling:74, color:'#0A5C36' },
  { id:3, name:'Dennis Mukhwana', team:CJS, pos:'DF', num:3, grade:'Grade 8', rating:7.9, goals:0, assists:3, xg:0.4, pass:82, pace:80, passing:78, shooting:52, defending:82, dribbling:72, color:'#0A5C36' },
  { id:4, name:'Ian Wanjala', team:CJS, pos:'DF', num:4, grade:'Grade 9', rating:8.4, goals:2, assists:1, xg:1.2, pass:86, pace:74, passing:82, shooting:62, defending:90, dribbling:68, color:'#FFC107', note:'Captain • Best defender' },
  { id:5, name:'Felix Nyongesa', team:CJS, pos:'DF', num:5, grade:'Grade 8', rating:8.1, goals:1, assists:2, xg:0.7, pass:84, pace:72, passing:80, shooting:58, defending:86, dribbling:66, color:'#0A5C36' },
  { id:6, name:'Victor Wafula', team:CJS, pos:'MF', num:6, grade:'Grade 9', rating:8.2, goals:3, assists:5, xg:2.6, pass:87, pace:78, passing:86, shooting:72, defending:78, dribbling:82, color:'#0A5C36' },
  { id:7, name:'Emmanuel Khaemba', team:CJS, pos:'FW', num:7, grade:'Grade 9', rating:8.8, goals:11, assists:5, xg:9.4, pass:81, pace:90, passing:80, shooting:90, defending:36, dribbling:88, color:'#FFC107', note:'Top scorer' },
  { id:8, name:'Daniel Masinde', team:CJS, pos:'MF', num:8, grade:'Grade 8', rating:8.3, goals:4, assists:6, xg:3.1, pass:89, pace:76, passing:88, shooting:74, defending:72, dribbling:84, color:'#0A5C36' },
  { id:9, name:'Joseph Wanyonyi', team:CJS, pos:'FW', num:9, grade:'Grade 9', rating:8.4, goals:8, assists:4, xg:7.2, pass:80, pace:88, passing:76, shooting:87, defending:34, dribbling:84, color:'#0A5C36' },
  { id:10, name:'Austin Barasa', team:CJS, pos:'MF', num:10, grade:'Grade 9', rating:8.5, goals:5, assists:8, xg:4.2, pass:90, pace:80, passing:91, shooting:78, defending:62, dribbling:89, color:'#FFC107', note:'Playmaker' },
  { id:11, name:'Peter Nalianya', team:CJS, pos:'FW', num:11, grade:'Grade 8', rating:8.0, goals:5, assists:7, xg:4.8, pass:83, pace:89, passing:82, shooting:80, defending:38, dribbling:86, color:'#0A5C36' },
  { id:12, name:'Samuel Wafula', team:CJS, pos:'MF', num:12, grade:'Grade 7', rating:7.6, goals:1, assists:3, xg:1.1, pass:82, pace:82, passing:80, shooting:66, defending:58, dribbling:78, color:'#0A5C36' },
  { id:13, name:'Titus Juma', team:CJS, pos:'DF', num:13, grade:'Grade 7', rating:7.7, goals:0, assists:1, xg:0.2, pass:80, pace:79, passing:76, shooting:50, defending:80, dribbling:68, color:'#0A5C36' },
  { id:14, name:'Moses Kibet', team:CJS, pos:'MF', num:14, grade:'Grade 8', rating:7.8, goals:2, assists:3, xg:1.6, pass:84, pace:77, passing:83, shooting:70, defending:64, dribbling:80, color:'#0A5C36' },
  { id:15, name:'Isaac Wamalwa', team:CJS, pos:'DF', num:15, grade:'Grade 7', rating:7.6, goals:0, assists:1, xg:0.1, pass:79, pace:76, passing:74, shooting:48, defending:79, dribbling:64, color:'#0A5C36' },
  { id:16, name:'Kevin Barasa', team:CJS, pos:'GK', num:16, grade:'Grade 7', rating:7.8, goals:0, assists:0, xg:0, pass:78, pace:66, passing:74, shooting:36, defending:78, dribbling:58, color:'#0A5C36' },
  { id:17, name:'Brian Makokha', team:CJS, pos:'FW', num:17, grade:'Grade 8', rating:7.9, goals:4, assists:2, xg:3.4, pass:79, pace:86, passing:74, shooting:82, defending:32, dribbling:82, color:'#0A5C36' },
  { id:18, name:'David Simiyu', team:CJS, pos:'FW', num:18, grade:'Grade 7', rating:7.5, goals:2, assists:2, xg:1.8, pass:78, pace:84, passing:72, shooting:78, defending:30, dribbling:80, color:'#0A5C36' },
];
const girlsBase: Player[] = [
  { id:101, name:'Grace Wanjiru', team:'Chebukwabi JS Girls', pos:'DF', num:4, grade:'Grade 9', rating:8.6, goals:3, assists:4, xg:2.1, pass:87, pace:78, passing:84, shooting:64, defending:90, dribbling:72, color:'#FFC107', note:'Captain • Leader at the back' },
  { id:102, name:'Faith Chebet', team:'Chebukwabi JS Girls', pos:'FW', num:9, grade:'Grade 9', rating:8.8, goals:10, assists:4, xg:8.6, pass:82, pace:90, passing:80, shooting:89, defending:34, dribbling:88, color:'#FFC107', note:'Top scorer' },
  { id:103, name:'Mercy Achieng', team:'Chebukwabi JS Girls', pos:'MF', num:10, grade:'Grade 9', rating:8.5, goals:5, assists:8, xg:4.4, pass:90, pace:80, passing:91, shooting:78, defending:62, dribbling:89, color:'#FFC107', note:'Playmaker' },
  { id:104, name:'Sarah Nekesa', team:'Chebukwabi JS Girls', pos:'GK', num:1, grade:'Grade 9', rating:8.3, goals:0, assists:0, xg:0, pass:83, pace:68, passing:79, shooting:38, defending:84, dribbling:62, color:'#0A5C36', note:'Safe hands • Commands the box' },
  { id:105, name:'Naomi Wafula', team:'Chebukwabi JS Girls', pos:'DF', num:2, grade:'Grade 8', rating:8.0, goals:1, assists:3, xg:0.7, pass:84, pace:82, passing:80, shooting:56, defending:84, dribbling:74, color:'#0A5C36' },
  { id:106, name:'Esther Barasa', team:'Chebukwabi JS Girls', pos:'DF', num:3, grade:'Grade 9', rating:8.1, goals:1, assists:2, xg:0.6, pass:83, pace:80, passing:78, shooting:54, defending:85, dribbling:71, color:'#0A5C36' },
  { id:107, name:'Ruth Simiyu', team:'Chebukwabi JS Girls', pos:'DF', num:5, grade:'Grade 8', rating:7.9, goals:0, assists:2, xg:0.3, pass:82, pace:76, passing:79, shooting:50, defending:83, dribbling:68, color:'#0A5C36' },
  { id:108, name:'Joyce Nalianya', team:'Chebukwabi JS Girls', pos:'MF', num:6, grade:'Grade 9', rating:8.2, goals:3, assists:5, xg:2.7, pass:87, pace:78, passing:86, shooting:72, defending:76, dribbling:82, color:'#0A5C36' },
  { id:109, name:'Doris Wanyonyi', team:'Chebukwabi JS Girls', pos:'FW', num:7, grade:'Grade 9', rating:8.4, goals:7, assists:4, xg:6.2, pass:81, pace:88, passing:78, shooting:86, defending:34, dribbling:84, color:'#0A5C36' },
  { id:110, name:'Beatrice Mukhwana', team:'Chebukwabi JS Girls', pos:'MF', num:8, grade:'Grade 8', rating:8.2, goals:4, assists:6, xg:3.0, pass:89, pace:76, passing:88, shooting:74, defending:72, dribbling:84, color:'#0A5C36' },
  { id:111, name:'Catherine Kibet', team:'Chebukwabi JS Girls', pos:'FW', num:11, grade:'Grade 8', rating:8.0, goals:5, assists:6, xg:4.5, pass:83, pace:89, passing:82, shooting:80, defending:38, dribbling:86, color:'#0A5C36' },
  { id:112, name:'Pamela Wekesa', team:'Chebukwabi JS Girls', pos:'MF', num:12, grade:'Grade 7', rating:7.6, goals:1, assists:3, xg:1.0, pass:82, pace:82, passing:80, shooting:66, defending:58, dribbling:78, color:'#0A5C36' },
  { id:113, name:'Winnie Juma', team:'Chebukwabi JS Girls', pos:'DF', num:13, grade:'Grade 7', rating:7.7, goals:0, assists:1, xg:0.2, pass:80, pace:79, passing:76, shooting:50, defending:80, dribbling:68, color:'#0A5C36' },
  { id:114, name:'Linet Masinde', team:'Chebukwabi JS Girls', pos:'MF', num:14, grade:'Grade 8', rating:7.8, goals:2, assists:3, xg:1.6, pass:84, pace:77, passing:83, shooting:70, defending:64, dribbling:80, color:'#0A5C36' },
  { id:115, name:'Diana Wamalwa', team:'Chebukwabi JS Girls', pos:'DF', num:15, grade:'Grade 7', rating:7.6, goals:0, assists:1, xg:0.1, pass:79, pace:76, passing:74, shooting:48, defending:79, dribbling:64, color:'#0A5C36' },
  { id:116, name:'Gloria Barasa', team:'Chebukwabi JS Girls', pos:'GK', num:16, grade:'Grade 7', rating:7.8, goals:0, assists:0, xg:0, pass:78, pace:66, passing:74, shooting:36, defending:78, dribbling:58, color:'#0A5C36' },
  { id:117, name:'Brenda Makokha', team:'Chebukwabi JS Girls', pos:'FW', num:17, grade:'Grade 8', rating:7.9, goals:4, assists:2, xg:3.3, pass:79, pace:86, passing:74, shooting:82, defending:32, dribbling:82, color:'#0A5C36' },
  { id:118, name:'Sharon Simiyu', team:'Chebukwabi JS Girls', pos:'FW', num:18, grade:'Grade 7', rating:7.5, goals:2, assists:2, xg:1.7, pass:78, pace:84, passing:72, shooting:78, defending:30, dribbling:80, color:'#0A5C36' },
];
const starterNotes = [
  { kind:'Next match', title:'Vs Namwela JS — game plan', body:'Start fast, press the first pass, and get the ball wide early. Keep one midfielder close to the back four when we attack.' },
  { kind:'Strength', title:'What is working', body:'High press and quick combinations on the left. Khaemba’s movement pulls defenders and opens space for late runs.' },
  { kind:'Weakness', title:'What to fix', body:'We concede from set-pieces when marking switches off at the far post. Practise marking and first contact this week.' },
  { kind:'Set-piece plan', title:'Corners — attacking', body:'Near-post run drags the first defender. Target the penalty spot for a second-ball finish. One player stays back.' },
];
const newsItems = [
  { tag:'Match Report', date:'Sat • Full Time • Chebukwabi JS Ground', title:'Boys win 3–1 — Khaemba at the double', body:'Chebukwabi JS boys produced a strong second half against Namwela JS. The press created both late goals and the home crowd stayed loud to the final whistle.', color:'#0A5C36', big:'3–1' },
  { tag:'Match Report', date:'Sat • Full Time • Chebukwabi JS Ground', title:'Girls shine — 2–0 win in the early kick-off', body:'The girls’ team controlled the game from the first whistle. Faith Chebet scored twice and the defence kept another clean sheet.', color:'#FFC107', big:'2–0' },
  { tag:'Training', date:'This week • Mon / Wed / Fri • 4:00 PM', title:'Training continues — boys & girls together', body:'All players bring boots, water and a positive attitude. New players are welcome to watch one session first, then join in. Arrive 15 minutes early.', color:'#0A5C36', big:'⚽' },
  { tag:'Trials', date:'Open to Grades 7, 8 and 9', title:'Trials open — Join The Team', body:'Do you love football? Come and try out. Fill in the Join Us form with your name, class, position and phone. No experience needed — discipline and teamwork first.', color:'#FFC107', big:'TRY' },
  { tag:'Announcement', date:'Coming soon • Sub-County School Games', title:'Sub-County tournament — we are ready', body:'Both our boys and girls will face Namwela, Mungore, Bumula and more. Parents and fans are welcome — come in green and gold.', color:'#0A5C36', big:'CJS' },
  { tag:'Announcement', date:'Thank you • Community', title:'Asante to every parent and fan', body:'Thank you for transport, lunch, kits and loud support. Your donations keep both teams on the pitch — balls, kits, transport and lunch.', color:'#FFC107', big:'♥' },
];
const leagueTable = [
  { team:'Kibachenje JS', p:12, w:9, d:2, l:1, gf:30, ga:10, pts:29 },
  { team:'Chebukwabi JS', p:12, w:8, d:3, l:1, gf:29, ga:11, pts:27 },
  { team:'Namwela JS', p:12, w:7, d:3, l:2, gf:24, ga:14, pts:24 },
  { team:'Mungore JS', p:12, w:6, d:3, l:3, gf:20, ga:15, pts:21 },
  { team:'Bumula JS', p:12, w:5, d:3, l:4, gf:18, ga:18, pts:18 },
  { team:'Khasoko JS', p:12, w:4, d:2, l:6, gf:16, ga:24, pts:14 },
];
const trainingSchedule = [
  { day:'Monday', daySw:'Jumatatu', time:'4:00 – 5:30 PM', focus:'Fitness + passing', focusSw:'Mazoezi ya mwili + kupiga pasi' },
  { day:'Wednesday', daySw:'Jumatano', time:'4:00 – 5:30 PM', focus:'Tactics + set-pieces', focusSw:'Mbinu + mipira ya adhabu' },
  { day:'Friday', daySw:'Ijumaa', time:'4:00 – 5:30 PM', focus:'Small games + finishing', focusSw:'Michezo midogo + kufunga' },
  { day:'Saturday', daySw:'Jumamosi', time:'10:00 AM', focus:'Match day', focusSw:'Siku ya mechi' },
];
const formations: Record<FormationKey, {label:string; x:number; y:number; role:string; num:number}[]> = {
  '4-3-3': [
    {label:'GK', x:50, y:90, role:'Goalkeeper', num:1}, {label:'LB', x:16, y:68, role:'Left Back', num:3}, {label:'CB', x:38, y:74, role:'Centre Back', num:4}, {label:'CB', x:62, y:74, role:'Centre Back', num:5}, {label:'RB', x:84, y:68, role:'Right Back', num:2},
    {label:'CM', x:28, y:48, role:'Central Mid', num:6}, {label:'CDM', x:50, y:58, role:'Holding Mid', num:8}, {label:'CM', x:72, y:48, role:'Central Mid', num:10},
    {label:'LW', x:18, y:22, role:'Left Wing', num:11}, {label:'ST', x:50, y:16, role:'Striker', num:9}, {label:'RW', x:82, y:22, role:'Right Wing', num:7},
  ],
  '4-4-2': [
    {label:'GK', x:50, y:90, role:'Goalkeeper', num:1}, {label:'LB', x:16, y:68, role:'Left Back', num:3}, {label:'CB', x:38, y:74, role:'Centre Back', num:4}, {label:'CB', x:62, y:74, role:'Centre Back', num:5}, {label:'RB', x:84, y:68, role:'Right Back', num:2},
    {label:'LM', x:14, y:42, role:'Left Mid', num:11}, {label:'CM', x:38, y:48, role:'Central Mid', num:6}, {label:'CM', x:62, y:48, role:'Central Mid', num:10}, {label:'RM', x:86, y:42, role:'Right Mid', num:8},
    {label:'ST', x:35, y:16, role:'Striker', num:9}, {label:'ST', x:65, y:16, role:'Striker', num:7},
  ],
  '3-5-2': [
    {label:'GK', x:50, y:90, role:'Goalkeeper', num:1}, {label:'CB', x:22, y:70, role:'Centre Back', num:3}, {label:'CB', x:50, y:76, role:'Centre Back', num:4}, {label:'CB', x:78, y:70, role:'Centre Back', num:5},
    {label:'LWB', x:10, y:42, role:'Wing Back', num:11}, {label:'CM', x:36, y:52, role:'Central Mid', num:6}, {label:'CDM', x:50, y:60, role:'Holding Mid', num:8}, {label:'CM', x:64, y:52, role:'Central Mid', num:10}, {label:'RWB', x:90, y:42, role:'Wing Back', num:2},
    {label:'ST', x:35, y:16, role:'Striker', num:9}, {label:'ST', x:65, y:16, role:'Striker', num:7},
  ],
  '4-2-3-1': [
    {label:'GK', x:50, y:90, role:'Goalkeeper', num:1}, {label:'LB', x:16, y:68, role:'Left Back', num:3}, {label:'CB', x:38, y:74, role:'Centre Back', num:4}, {label:'CB', x:62, y:74, role:'Centre Back', num:5}, {label:'RB', x:84, y:68, role:'Right Back', num:2},
    {label:'CDM', x:38, y:52, role:'Holding Mid', num:6}, {label:'CDM', x:62, y:52, role:'Holding Mid', num:8},
    {label:'LW', x:16, y:26, role:'Left Wing', num:11}, {label:'CAM', x:50, y:34, role:'Attacking Mid', num:10}, {label:'RW', x:84, y:26, role:'Right Wing', num:7},
    {label:'ST', x:50, y:14, role:'Striker', num:9},
  ],
};
const STR = {
  en: { home:'Home', boys:'Boys Team', girls:'Girls Team', fixtures:'Fixtures', tactical:'Tactical Board', analysis:'Match Analysis', news:'News', join:'Join Us', donate:'Donate', portal:'Portal', tagline:'Pride of Chebukwabi | Discipline • Teamwork • Excellence', next:'Next Match', last:'Last Result', stats:'Season Stats', about:'About Chebukwabi JS', stars:'Star Players', latest:'Latest News', gallery:'Gallery', contact:'Contact / Join Us', welcome:'Welcome to Chebukwabi JS', choose:'Choose your role — no password needed.', coach:'Coach', player:'Player', parent:'Parent / Fan', training:'Training Schedule', announcements:'Coach Announcements', league:'League Table', scorers:'Top Scorers', photos:'Team Photos', attendance:'Attendance', myProfile:'My Profile', myStats:'My Stats', viewFixtures:'View Fixtures', enterPortal:'Enter Portal', joinTeam:'Join The Team' },
  sw: { home:'Nyumbani', boys:'Timu ya Wavulana', girls:'Timu ya Wasichana', fixtures:'Mechi', tactical:'Bodi ya Mbinu', analysis:'Uchambuzi wa Mechi', news:'Habari', join:'Jiunge Nasi', donate:'Changia', portal:'Portal', tagline:'Fahari ya Chebukwabi | Nidhamu • Kazi ya Timu • Ubora', next:'Mechi Ijayo', last:'Matokeo ya Mwisho', stats:'Takwimu za Msimu', about:'Kuhusu Chebukwabi JS', stars:'Wachezaji Bora', latest:'Habari za Hivi Karibuni', gallery:'Picha', contact:'Wasiliana / Jiunge Nasi', welcome:'Karibu Chebukwabi JS', choose:'Chagua jukumu lako — hakuna neno la siri.', coach:'Kocha', player:'Mchezaji', parent:'Mzazi / Shabiki', training:'Ratiba ya Mazoezi', announcements:'Matangazo ya Kocha', league:'Msimamo wa Ligi', scorers:'Wafungaji Bora', photos:'Picha za Timu', attendance:'Mahudhurio', myProfile:'Wasifu Wangu', myStats:'Takwimu Zangu', viewFixtures:'Tazama Mechi', enterPortal:'Ingia Portal', joinTeam:'Jiunge na Timu' },
} as Record<Lang, Record<string,string>>;

async function api(action:string, args:Record<string,unknown>){
  const res = await fetch("actions", { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({action, args}) });
  const json = await res.json().catch(()=>({}));
  if(!res.ok || json.error) throw new Error(json.error || 'Request failed');
  return json.data;
}
function Badge({short, color, size=54}:{short:string; color:string; size?:number}) {
  return <div className="flex items-center justify-center rounded-full font-black shrink-0" style={{width:size, height:size, background:color, color: color==='#FFC107' ? '#111' : '#fff', fontSize:size*0.28, boxShadow:'0 6px 18px rgba(0,0,0,.35)', border:'2px solid rgba(255,255,255,.25)'}}>{short}</div>;
}
function Form({form}:{form:string[]}) {
  return <div className="flex gap-1.5">{form.map((f,i)=><span key={i} className="w-7 h-7 rounded-full grid place-items-center text-[11px] font-black" style={{background: f==='W'?'#FFC107':f==='D'?'#fff':'#ff5a5a', color:'#0a140d'}}>{f}</span>)}</div>;
}
function StatRow({label, home, away, homeMax, awayMax, suffix=''}:{label:string; home:number; away:number; homeMax:number; awayMax:number; suffix?:string}) {
  return <div className="py-3 border-b border-[var(--line)] last:border-0">
    <div className="flex justify-between text-[13px] mb-2"><span className="mono font-bold text-[var(--accent)]">{home}{suffix}</span><span className="font-semibold text-[var(--muted)] tracking-wide">{label}</span><span className="mono font-bold">{away}{suffix}</span></div>
    <div className="flex gap-2 h-2.5"><div className="flex-1 bg-[#0a1a10] rounded-full overflow-hidden flex justify-end"><div className="h-full bg-[var(--accent)] rounded-full" style={{width:`${(home/homeMax)*100}%`}}/></div><div className="flex-1 bg-[#0a1a10] rounded-full overflow-hidden"><div className="h-full bg-white/80 rounded-full" style={{width:`${(away/awayMax)*100}%`}}/></div></div>
  </div>;
}

function JoinForm({compact=false}:{compact?:boolean}){
  const [name,setName]=useState(''); const [gender,setGender]=useState('Boy'); const [grade,setGrade]=useState('Grade 8'); const [pos,setPos]=useState('MF'); const [phone,setPhone]=useState(''); const [guardian,setGuardian]=useState('');
  const [busy,setBusy]=useState(false); const [msg,setMsg]=useState<string|null>(null);
  async function submit(){
    if(!name.trim()){ setMsg('Please add your full name first. / Tafadhali andika jina lako kamili kwanza.'); return; }
    if(!phone.trim()){ setMsg('Please add your phone number. / Tafadhali andika namba yako ya simu.'); return; }
    if(!guardian.trim()){ setMsg('Please add a guardian phone number. / Tafadhali andika namba ya simu ya mzazi / mlezi.'); return; }
    setBusy(true); setMsg(null);
    try{
      const key = `join-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
      await api('records.create',{collection:'chebukwabi_join_requests', value:{name:name.trim(), gender, grade, pos, phone:phone.trim(), guardianPhone:guardian.trim(), createdLabel:new Date().toISOString().slice(0,10)}, idempotency_key:key});
      setMsg(`Asante, ${name.trim()}! Coach will contact you. / Asante! Kocha atawasiliana nawe.`);
      setName(''); setPhone(''); setGuardian('');
    }catch(e){ setMsg(e instanceof Error?e.message:String(e)); }
    setBusy(false);
  }
  return <div className="bg-white text-[#0a1a10] rounded-[24px] p-5 shadow-lg">
    <h3 className="font-black text-xl leading-tight">Join The Team <span className="text-[#0A5C36]">• Jiunge na Timu</span></h3>
    <p className="text-[13px] text-[#4a5a50] mt-1">Fill this form. It is saved for the coach. No login needed. / Jaza fomu hii. Itahifadhiwa kwa kocha.</p>
    <div className="grid sm:grid-cols-2 gap-3 mt-4">
      <label className="block text-sm font-bold sm:col-span-2">Full Name / Jina Kamili<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Kevin Wekesa" className="w-full mt-1 min-h-[52px] bg-[#f2f7f2] border border-[#d7e5da] rounded-2xl px-4 outline-none"/></label>
      <label className="block text-sm font-bold">Gender / Jinsia<select value={gender} onChange={e=>setGender(e.target.value)} className="w-full mt-1 min-h-[52px] bg-[#f2f7f2] border border-[#d7e5da] rounded-2xl px-4"><option>Boy</option><option>Girl</option></select></label>
      <label className="block text-sm font-bold">Class / Darasa<select value={grade} onChange={e=>setGrade(e.target.value)} className="w-full mt-1 min-h-[52px] bg-[#f2f7f2] border border-[#d7e5da] rounded-2xl px-4"><option>Grade 7</option><option>Grade 8</option><option>Grade 9</option></select></label>
      <label className="block text-sm font-bold">Position / Nafasi<select value={pos} onChange={e=>setPos(e.target.value)} className="w-full mt-1 min-h-[52px] bg-[#f2f7f2] border border-[#d7e5da] rounded-2xl px-4"><option value="GK">Goalkeeper (GK)</option><option value="DF">Defender (DF)</option><option value="MF">Midfielder (MF)</option><option value="FW">Forward (FW)</option><option value="Any">Any / Yoyote</option></select></label>
      <label className="block text-sm font-bold">Phone / Simu<input value={phone} onChange={e=>setPhone(e.target.value)} inputMode="tel" placeholder="e.g. 0712 345 678" className="w-full mt-1 min-h-[52px] bg-[#f2f7f2] border border-[#d7e5da] rounded-2xl px-4 outline-none"/></label>
      <label className="block text-sm font-bold sm:col-span-2">Guardian Phone / Simu ya Mzazi / Mlezi<input value={guardian} onChange={e=>setGuardian(e.target.value)} inputMode="tel" placeholder="e.g. 0722 123 456" className="w-full mt-1 min-h-[52px] bg-[#f2f7f2] border border-[#d7e5da] rounded-2xl px-4 outline-none"/></label>
    </div>
    {!compact && <p className="text-[13px] text-[#4a5a50] mt-3">By joining you agree to train with discipline, respect teammates, and listen to the coach. / Kwa kujiunga unakubali mazoezi kwa nidhamu na heshima.</p>}
    <button onClick={submit} disabled={busy} className="w-full min-h-[56px] mt-4 rounded-full bg-[#FFC107] text-black font-black text-[16px] disabled:opacity-50">{busy?'Saving… / Inahifadhiwa…':'Send Request • Tuma Ombi'}</button>
    {msg && <p role="status" className="mt-3 text-sm font-semibold bg-[#fff3c4] border border-[#FFC107] rounded-xl px-3 py-2">{msg}</p>}
  </div>;
}

export default function App(){
  const [lang,setLang]=useState<Lang>('en'); const t=STR[lang];
  const [section,setSection]=useState<Section>('Home');
  const [role,setRole]=useState<Role>(null);
  const [portalTab,setPortalTab]=useState<PortalTab>('Dashboard');
  const [analysisTeam, setAnalysisTeam] = useState<TeamKey>('Boys');
  const [analysisId, setAnalysisId] = useState('B-CJS-NAM');
  const match = allMatches.find(m=>m.id===analysisId) || allMatches[0];
  const [formation, setFormation] = useState<FormationKey>('4-3-3');
  const [tacticalTeam, setTacticalTeam] = useState<TeamKey>('Boys');
  const [side, setSide] = useState<'Home'|'Away'>('Home');
  const [showAvg, setShowAvg] = useState(true);
  const [positions, setPositions] = useState(formations['4-3-3']);
  const [dragId, setDragId] = useState<number|null>(null);
  const [query, setQuery] = useState('');
  const [boysTab, setBoysTab] = useState<'Squad'|'Stats'|'Fixtures'>('Squad');
  const [girlsTab, setGirlsTab] = useState<'Squad'|'Stats'|'Fixtures'>('Squad');
  const [donateAmount, setDonateAmount] = useState(500);
  const [donated, setDonated] = useState(false);
  const pitchRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [savedPlayers, setSavedPlayers] = useState<SavedPlayer[]>([]);
  const [savedNotes, setSavedNotes] = useState<SavedNote[]>([]);
  const [joinRequests, setJoinRequests] = useState<{id:string; name:string; gender:string; grade:string; pos:string; phone:string; guardianPhone:string}[]>([]);
  const [attendanceRecs, setAttendanceRecs] = useState<{id:string; date:string; name:string; status:string}[]>([]);
  const [loadError, setLoadError] = useState<string|null>(null);
  const [busy, setBusy] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string|null>(null);
  const [noteMessage, setNoteMessage] = useState<string|null>(null);
  const [showAddPlayer, setShowAddPlayer] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPos, setNewPos] = useState('MF');
  const [newNum, setNewNum] = useState('');
  const [newGrade, setNewGrade] = useState('Grade 8');
  const [newNote, setNewNote] = useState('');
  const [newTeam, setNewTeam] = useState<TeamKey>('Boys');
  const [noteKind, setNoteKind] = useState('Next match');
  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');
  const [attDate,setAttDate]=useState(()=>new Date().toISOString().slice(0,10));
  const [attTeam,setAttTeam]=useState<TeamKey>('Boys');
  const [presentIds,setPresentIds]=useState<Set<number>>(new Set(basePlayers.map(p=>p.id)));
  const [attResult,setAttResult]=useState<{saved:number; remaining:number; error:string|null; reloadError:string|null}|null>(null);
  const [attBusy,setAttBusy]=useState(false);

  const players: Player[] = useMemo(()=> {
    const extra: Player[] = savedPlayers.filter(s=>s.team==='Boys').map((sp, i)=> ({ id:100+i, name:sp.name, team:CJS, pos:sp.pos, num:sp.num, grade:sp.grade, rating:7.5, goals:0, assists:0, xg:0, pass:80, pace:78, passing:78, shooting:68, defending:62, dribbling:76, color:'#0A5C36', note:sp.note || undefined }));
    return [...basePlayers, ...extra];
  }, [savedPlayers]);
  const girlsPlayers: Player[] = useMemo(()=> {
    const extra: Player[] = savedPlayers.filter(s=>s.team==='Girls').map((sp, i)=> ({ id:200+i, name:sp.name, team:'Chebukwabi JS Girls', pos:sp.pos, num:sp.num, grade:sp.grade, rating:7.5, goals:0, assists:0, xg:0, pass:80, pace:78, passing:78, shooting:68, defending:62, dribbling:76, color:'#0A5C36', note:sp.note || undefined }));
    return [...girlsBase, ...extra];
  }, [savedPlayers]);
  const [selectedPlayer, setSelectedPlayer] = useState<Player>(basePlayers[0]);
  const [selectedGirl, setSelectedGirl] = useState<Player>(girlsBase[0]);
  const [myTeam, setMyTeam] = useState<TeamKey>('Boys');
  const [myPlayerId,setMyPlayerId]=useState(7);

  async function reloadRecords(){
    const [p, n, j, a] = await Promise.all([
      api('records.list', {collection:'chebukwabi_players'}),
      api('records.list', {collection:'chebukwabi_notes'}),
      api('records.list', {collection:'chebukwabi_join_requests'}),
      api('records.list', {collection:'chebukwabi_attendance'}),
    ]);
    const pRecs = (p?.records || []) as {id:string; value:any}[];
    const nRecs = (n?.records || []) as {id:string; value:any}[];
    const jRecs = (j?.records || []) as {id:string; value:any}[];
    const aRecs = (a?.records || []) as {id:string; value:any}[];
    setSavedPlayers(pRecs.map(r=>({ id:r.id, name:String(r.value?.name||''), pos:String(r.value?.pos||'MF'), num:Number(r.value?.num||0), grade:String(r.value?.grade||'Grade 8'), note:String(r.value?.note||''), team:String(r.value?.team||'Boys') })).filter(x=>x.name));
    setSavedNotes(nRecs.map(r=>({ id:r.id, kind:String(r.value?.kind||'Next match'), title:String(r.value?.title||''), body:String(r.value?.body||'') })).filter(x=>x.title || x.body));
    setJoinRequests(jRecs.map(r=>({id:r.id, name:String(r.value?.name||''), gender:String(r.value?.gender||''), grade:String(r.value?.grade||''), pos:String(r.value?.pos||''), phone:String(r.value?.phone||''), guardianPhone:String(r.value?.guardianPhone||r.value?.guardian||'')})).filter(x=>x.name));
    setAttendanceRecs(aRecs.map(r=>({id:r.id, date:String(r.value?.date||''), name:String(r.value?.player||r.value?.name||''), status:String(r.value?.status||'')})));
  }
  useEffect(()=>{ reloadRecords().catch((e)=> setLoadError(e instanceof Error ? e.message : String(e))); }, []);
  const filtered = useMemo(()=> players.filter(p=> p.name.toLowerCase().includes(query.toLowerCase()) || p.pos.toLowerCase().includes(query.toLowerCase()) || p.grade.toLowerCase().includes(query.toLowerCase())), [query, players]);
  const filteredGirls = useMemo(()=> girlsPlayers.filter(p=> p.name.toLowerCase().includes(query.toLowerCase()) || p.pos.toLowerCase().includes(query.toLowerCase()) || p.grade.toLowerCase().includes(query.toLowerCase())), [query, girlsPlayers]);
  const myPool = myTeam==='Boys' ? players : girlsPlayers;
  const myPlayer = myPool.find(p=>p.id===myPlayerId) || myPool[0];
  const playerByNum = (team:TeamKey, num:number)=> (team==='Boys'?players:girlsPlayers).find(p=>p.num===num) || (team==='Boys'?basePlayers:girlsBase).find(p=>p.num===num)!;
  const topScorers = [...players].sort((a,b)=>b.goals-a.goals).slice(0,5);
  const topGirls = [...girlsPlayers].sort((a,b)=>b.goals-a.goals).slice(0,5);

  useEffect(()=>{ setPositions(formations[formation]); }, [formation]);
  useEffect(()=>{
    const c = canvasRef.current; if(!c) return;
    const dpr = window.devicePixelRatio || 1; const w = c.clientWidth, h = c.clientHeight;
    if(!w) return;
    c.width = w*dpr; c.height = h*dpr; const ctx = c.getContext('2d'); if(!ctx) return;
    ctx.scale(dpr,dpr); ctx.clearRect(0,0,w,h);
    ctx.strokeStyle='rgba(255,255,255,.12)'; ctx.lineWidth=1;
    for(let i=1;i<4;i++){ ctx.beginPath(); ctx.moveTo(0, h*i/4); ctx.lineTo(w, h*i/4); ctx.stroke(); }
    ctx.beginPath(); ctx.moveTo(0,h*0.5); ctx.lineTo(w,h*0.5); ctx.setLineDash([4,5]); ctx.strokeStyle='rgba(255,197,61,.55)'; ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath();
    match.momentum.forEach((v,i)=>{ const x = (i/(match.momentum.length-1))*w; const y = h - (v/100)*(h-28) - 10; if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y); });
    ctx.strokeStyle='#FFC107'; ctx.lineWidth=3; ctx.lineJoin='round'; ctx.stroke();
    match.momentum.forEach((v,i)=>{ const x=(i/(match.momentum.length-1))*w; const y=h-(v/100)*(h-28)-10; ctx.beginPath(); ctx.arc(x,y,4,0,Math.PI*2); ctx.fillStyle= v>60 ? '#FFC107' : '#fff'; ctx.fill(); });
    ctx.fillStyle='#a8bfae'; ctx.font='11px JetBrains Mono'; ctx.fillText('CHEBUKWABI DOMINANCE →', 10, 18); ctx.fillText('OPPONENT DOMINANCE →', 10, h-8);
  }, [match, section, portalTab, analysisTeam, analysisId]);

  const onPitchPointer = (e: React.PointerEvent) => {
    if(dragId===null || !pitchRef.current) return;
    const r = pitchRef.current.getBoundingClientRect();
    const x = Math.max(4, Math.min(96, ((e.clientX - r.left)/r.width)*100));
    const y = Math.max(4, Math.min(96, ((e.clientY - r.top)/r.height)*100));
    setPositions(prev => prev.map((p,i)=> i===dragId ? {...p, x, y} : p));
  };
  async function createRow(collection:string, value:Record<string,unknown>){
    const key = `${collection}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    return api('records.create', {collection, value, idempotency_key:key});
  }
  async function addPlayer(){
    if(!newName.trim() || !newNum.trim()){ setSaveMessage('Add a player name and shirt number first.'); return; }
    const num = Number(newNum);
    if(!Number.isInteger(num) || num<1 || num>99){ setSaveMessage('Shirt number must be a whole number from 1 to 99.'); return; }
    setBusy(true); setSaveMessage(null);
    try{
      await createRow('chebukwabi_players', {name:newName.trim(), pos:newPos, num, grade:newGrade, note:newNote.trim(), team:newTeam});
      await reloadRecords();
      setSaveMessage(`Saved — ${newName.trim()} is now in the Chebukwabi JS ${newTeam.toLowerCase()} squad.`);
      setNewName(''); setNewNum(''); setNewNote(''); setShowAddPlayer(false);
    }catch(e){ setSaveMessage(e instanceof Error ? e.message : String(e)); }
    setBusy(false);
  }
  async function addNote(){
    if(!noteTitle.trim() && !noteBody.trim()){ setNoteMessage('Add a title or note text first.'); return; }
    setBusy(true); setNoteMessage(null);
    try{
      await createRow('chebukwabi_notes', {kind:noteKind, title:noteTitle.trim() || noteKind, body:noteBody.trim()});
      await reloadRecords();
      setNoteMessage('Coach note saved.');
      setNoteTitle(''); setNoteBody('');
    }catch(e){ setNoteMessage(e instanceof Error ? e.message : String(e)); }
    setBusy(false);
  }
  async function deleteNote(id:string){
    setBusy(true);
    try{ await api('records.delete', {collection:'chebukwabi_notes', id}); await reloadRecords(); setNoteMessage('Coach note removed.'); }
    catch(e){ setNoteMessage(e instanceof Error ? e.message : String(e)); }
    setBusy(false);
  }
  async function deletePlayer(id:string){
    setBusy(true);
    try{ await api('records.delete', {collection:'chebukwabi_players', id}); await reloadRecords(); setSaveMessage('Player removed from the saved squad additions.'); }
    catch(e){ setSaveMessage(e instanceof Error ? e.message : String(e)); }
    setBusy(false);
  }
  async function saveAttendance(){
    const pool = attTeam==='Boys'?players:girlsPlayers;
    const rows = pool.map(p=>({date:attDate, team:attTeam, player:p.name, num:p.num, status: presentIds.has(p.id) ? 'Present' : 'Absent'}));
    setAttBusy(true); let saved=0; let error:string|null=null;
    try{ for(const row of rows){ await createRow('chebukwabi_attendance', row); saved+=1; } }
    catch(e){ error = e instanceof Error ? e.message : String(e); }
    let reloadError:string|null=null; try{ await reloadRecords(); }catch(e){ reloadError = e instanceof Error ? e.message : String(e); }
    setAttResult({saved, remaining: rows.length - saved, error, reloadError}); setAttBusy(false);
  }
  function go(s:Section){ setSection(s); window.scrollTo({top:0, behavior:'smooth'}); }
  function openPortal(r:Role, tab:PortalTab='Dashboard'){ setRole(r); setPortalTab(tab); setSection('Portal'); window.scrollTo({top:0}); }
  const nav: {label:string; key:Section}[] = [
    {label:t.home, key:'Home'}, {label:t.boys, key:'Boys'}, {label:t.girls, key:'Girls'}, {label:t.fixtures, key:'Fixtures'}, {label:t.tactical, key:'Tactical'}, {label:t.analysis, key:'Analysis'}, {label:t.news, key:'News'}, {label:t.join, key:'Join'}, {label:t.donate, key:'Donate'}, {label:t.portal, key:'Portal'},
  ];
  const coachTabs: PortalTab[] = ['Dashboard','Squad','Attendance','Notes'];
  const playerTabs: PortalTab[] = ['My Profile','Training','Announcements'];
  const parentTabs: PortalTab[] = ['Fixtures','News','Team Photos'];

  const seasonStats = <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
    {[{l: lang==='sw'?'Mechi':'Played', v:String(season.played)},{l: lang==='sw'?'Ushindi':'Won', v:String(season.won)},{l: lang==='sw'?'Sare':'Drawn', v:String(season.drawn)},{l: lang==='sw'?'Kupoteza':'Lost', v:String(season.lost)},{l: lang==='sw'?'Magoli':'Goals', v:String(season.gf)}].map(s=> <div key={s.l} className="bg-white rounded-[20px] p-4 text-[#0a1a10] border border-[#d7e5da]"><div className="text-[11px] font-black tracking-wide text-[#0A5C36]">{s.l.toUpperCase()}</div><div className="text-[28px] font-black leading-tight">{s.v}</div><div className="text-[12px] text-[#5a6a60]">{s.l==='Goals'?'Scored this season • Boys + Girls':'This season'}</div></div>)}
  </div>;
  const fixturesTwoCol = <div className="grid lg:grid-cols-2 gap-4">
    <section className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><div className="flex justify-between items-center"><h3 className="font-black text-xl">Boys Fixtures • Wavulana</h3><span className="text-[11px] font-black bg-[#0A5C36] text-white px-2 py-1 rounded-full">COACH GALVIN</span></div><div className="space-y-2 mt-4">{boysFixtures.map((f,i)=> <div key={i} className="bg-[#0a1a10] rounded-2xl p-4"><div className="flex justify-between gap-2"><b className="text-[14px]">vs {f.opp}</b><span className="mono text-[11px] text-[var(--accent)] shrink-0">{f.date}</span></div><p className="text-[13px] text-[var(--muted)] mt-1 flex items-center gap-1"><MapPin size={13}/> {f.venue} • {f.comp}</p><p className="text-[13px] mt-1">{f.note}</p></div>)}</div></section>
    <section className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><div className="flex justify-between items-center"><h3 className="font-black text-xl">Girls Fixtures • Wasichana</h3><span className="text-[11px] font-black bg-[#FFC107] text-black px-2 py-1 rounded-full">COACH MARY</span></div><div className="space-y-2 mt-4">{girlsFixtures.map((f,i)=> <div key={i} className="bg-[#0a1a10] rounded-2xl p-4"><div className="flex justify-between gap-2"><b className="text-[14px]">vs {f.opp}</b><span className="mono text-[11px] text-[var(--accent)] shrink-0">{f.date}</span></div><p className="text-[13px] text-[var(--muted)] mt-1 flex items-center gap-1"><MapPin size={13}/> {f.venue} • {f.comp}</p><p className="text-[13px] mt-1">{f.note}</p></div>)}</div></section>
  </div>;
  const newsCards = <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
    {newsItems.map((n,i)=> <article key={i} className="bg-white rounded-[24px] overflow-hidden text-[#0a1a10] border border-[#d7e5da] flex flex-col"><div className="h-[110px] flex items-center justify-between px-5" style={{background:n.color}}><span className="text-[34px] font-black" style={{color:n.color==='#FFC107'?'#111':'#FFC107'}}>{n.big}</span><span className="text-[11px] font-black bg-white/90 px-2 py-1 rounded-full">{n.tag.toUpperCase()}</span></div><div className="p-5 flex flex-col flex-1"><p className="text-[12px] text-[#5a6a60] font-semibold">{n.date}</p><h3 className="font-black text-[19px] leading-tight mt-1">{n.title}</h3><p className="text-[14px] text-[#4a5a50] leading-relaxed mt-2 flex-1">{n.body}</p><button onClick={()=>go('Join')} className="mt-4 min-h-[48px] rounded-full bg-[#0A5C36] text-white font-bold text-sm">Join Us • Jiunge Nasi →</button></div></article>)}
  </div>;
  const galleryStrip = <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
    {[{bg:'#0A5C36', fg:'#FFC107', big:'CJS', small:'Green & Gold'},{bg:'#FFC107', fg:'#0A5C36', big:'⚽', small:'Training • Mazoezi'},{bg:'#ffffff', fg:'#0A5C36', big:'2nd', small:'League • Ligi'},{bg:'#123a26', fg:'#fff', big:'29', small:'Goals • Magoli'}].map((g,i)=> <div key={i} className="rounded-[22px] p-5 min-h-[132px] flex flex-col justify-between border border-[#d7e5da]" style={{background:g.bg, color:g.fg}}><span className="text-[36px] font-black leading-none">{g.big}</span><span className="text-[13px] font-bold">{g.small}</span><span className="text-[11px] opacity-70">Chebukwabi JS • Bungoma</span></div>)}
  </div>;
  const matchCardList = (list:Match[]) => <div className="flex gap-4 overflow-x-auto scroll-row snap-x snap-mandatory pb-2 -mx-1 px-1">
    {list.map(m=>(
      <article key={m.id} className="snap-start shrink-0 w-[86vw] max-w-[400px] sm:w-[380px] bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5">
        <div className="flex justify-between items-center"><span className="text-[11px] mono font-bold text-[var(--accent)]">{m.comp} • {m.team.toUpperCase()}</span><span className="text-[10px] font-black bg-white/10 px-2 py-1 rounded-full">{m.status}</span></div>
        <div className="flex items-center justify-between mt-5 gap-2">
          <div className="flex flex-col items-center gap-2 text-center flex-1"><Badge short={m.shortH} color={m.homeColor}/><b className="text-[15px] leading-tight">{m.home}</b><Form form={m.formH}/></div>
          <div className="text-center px-1"><div className="text-[28px] font-black whitespace-nowrap">{m.score}</div><div className="text-[11px] text-[var(--muted)] mono">{m.date}</div><div className="text-[11px] text-[var(--muted)] mt-1">POS {m.poss[0]}% — {m.poss[1]}%</div></div>
          <div className="flex flex-col items-center gap-2 text-center flex-1"><Badge short={m.shortA} color={m.awayColor}/><b className="text-[15px] leading-tight">{m.away}</b><Form form={m.formA}/></div>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-5">
          <div className="bg-[#0a1a10] rounded-2xl p-3 text-center"><div className="text-[10px] text-[var(--muted)] font-bold">xG</div><div className="mono font-bold text-[15px] mt-1">{m.xg[0].toFixed(2)} <span className="text-[var(--muted)]">/ {m.xg[1].toFixed(2)}</span></div></div>
          <div className="bg-[#0a1a10] rounded-2xl p-3 text-center"><div className="text-[10px] text-[var(--muted)] font-bold">SHOTS</div><div className="mono font-bold text-[15px] mt-1">{m.shots[0]} <span className="text-[var(--muted)]">/ {m.shots[1]}</span></div></div>
          <div className="bg-[#0a1a10] rounded-2xl p-3 text-center"><div className="text-[10px] text-[var(--muted)] font-bold">PASSES</div><div className="mono font-bold text-[15px] mt-1">{m.passes[0]} <span className="text-[var(--muted)]">/ {m.passes[1]}</span></div></div>
        </div>
        <button onClick={()=>{setAnalysisTeam(m.team); setAnalysisId(m.id); go('Analysis');}} className="w-full min-h-[48px] mt-4 rounded-full bg-[#FFC107] text-black font-black text-sm">Open Match Analysis →</button>
      </article>
    ))}
  </div>;

  function SquadBlock({teamKey, list, selected, onSelect, tab, setTab}:{teamKey:TeamKey; list:Player[]; selected:Player; onSelect:(p:Player)=>void; tab:'Squad'|'Stats'|'Fixtures'; setTab:(v:'Squad'|'Stats'|'Fixtures')=>void}){
    const coach = teamKey==='Boys' ? 'Coach Galvin' : 'Coach Mary';
    const captain = teamKey==='Boys' ? players[3] : girlsPlayers[0];
    const scorers = [...list].sort((a,b)=>b.goals-a.goals).slice(0,5);
    return <div>
      <div className="flex flex-wrap gap-2"><span className="min-h-[48px] px-4 rounded-full bg-[#FFC107] text-black font-black text-sm flex items-center">{coach}</span><span className="min-h-[48px] px-4 rounded-full bg-[#122a1b] border border-[var(--line)] text-sm font-bold flex items-center">Captain: {captain.name} • #{captain.num}</span><span className="min-h-[48px] px-4 rounded-full bg-[#122a1b] border border-[var(--line)] text-sm font-bold flex items-center">{list.length} players • Grades 7 • 8 • 9</span></div>
      <div className="flex gap-2 mt-4">{(['Squad','Stats','Fixtures'] as const).map(x=> <button key={x} onClick={()=>setTab(x)} className={`min-h-[48px] px-5 rounded-full font-black text-sm ${tab===x?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>{x}</button>)}</div>
      {tab==='Squad' && <div className="grid lg:grid-cols-[1fr_360px] gap-4 items-start mt-4">
        <div><label className="relative block"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted)]" size={20}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={`Search ${teamKey.toLowerCase()} player, position or class…`} className="w-full min-h-[56px] bg-[var(--surface)] border border-[var(--line)] rounded-full pl-12 pr-4 text-[16px] outline-none placeholder:text-[var(--muted-2)]"/></label>
        <div className="grid sm:grid-cols-2 gap-3 mt-4">{(teamKey==='Boys'?filtered:filteredGirls).map(p=> <button key={p.id} onClick={()=>onSelect(p)} className={`text-left p-4 rounded-[20px] border min-h-[96px] flex gap-3 items-center ${selected.id===p.id?'bg-[#FFC107] text-black border-[#FFC107]':'bg-[var(--surface)] border-[var(--line)]'}`}><span className="w-[58px] h-[58px] rounded-full grid place-items-center font-black text-[15px] shrink-0" style={{background:p.color, color: p.color==='#FFC107'?'#111':'#fff'}}>{p.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</span><span className="flex-1 min-w-0"><span className="block font-black leading-tight truncate">{p.name} {p.note?.includes('Captain') && <span className="text-[11px] bg-black text-white px-2 py-0.5 rounded-full ml-1">CAPTAIN • C</span>}</span><span className={`block text-[13px] mt-0.5 ${selected.id===p.id?'text-black/70':'text-[var(--muted)]'}`}>{p.team} • {p.pos} • #{p.num} • {p.grade}</span><span className="flex gap-2 mt-2 flex-wrap"><span className="text-[11px] font-bold bg-black/10 px-2 py-1 rounded-full">{p.goals} G</span><span className="text-[11px] font-bold bg-black/10 px-2 py-1 rounded-full">{p.assists} A</span><span className="text-[11px] font-bold bg-black/10 px-2 py-1 rounded-full">{p.pass}% PASS</span></span>{p.note && <span className="block text-[12px] font-bold mt-1">{p.note}</span>}</span><span className="text-right shrink-0"><span className="block text-[22px] font-black leading-none">{p.rating.toFixed(1)}</span><span className="text-[10px] font-bold opacity-70">RATING</span></span></button>)}</div></div>
        <aside className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 lg:sticky lg:top-[170px]"><div className="flex gap-3 items-center"><span className="w-[68px] h-[68px] rounded-full grid place-items-center font-black text-lg shrink-0" style={{background:selected.color, color:selected.color==='#FFC107'?'#111':'#fff'}}>{selected.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</span><div className="min-w-0"><h3 className="font-black text-[22px] leading-tight">{selected.name}</h3><p className="text-[13px] text-[var(--muted)]">{selected.team} • {selected.pos} • #{selected.num} • {selected.grade}</p></div><div className="ml-auto text-right"><div className="text-[26px] font-black text-[var(--accent)] leading-none">{selected.rating.toFixed(1)}</div><div className="text-[10px] text-[var(--muted)] font-bold">RATING</div></div></div>{selected.note && <p className="mt-3 text-sm font-bold bg-[#FFC107]/10 border border-[#FFC107]/30 rounded-xl px-3 py-2">{selected.note}</p>}<div className="grid grid-cols-4 gap-2 mt-5 text-center"><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block">{selected.goals}</b><span className="text-[10px] text-[var(--muted)] font-bold">GOALS</span></div><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block">{selected.assists}</b><span className="text-[10px] text-[var(--muted)] font-bold">ASSISTS</span></div><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block">{selected.xg}</b><span className="text-[10px] text-[var(--muted)] font-bold">xG</span></div><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block">{selected.pass}%</b><span className="text-[10px] text-[var(--muted)] font-bold">PASS</span></div></div><h4 className="font-black mt-5 mb-2 flex items-center gap-2"><Shield size={16} className="text-[var(--accent)]"/> Attribute profile</h4>{([['Pace',selected.pace],['Passing',selected.passing],['Shooting',selected.shooting],['Defending',selected.defending],['Dribbling',selected.dribbling]] as [string,number][]).map(([label,val])=> <div key={label} className="py-2"><div className="flex justify-between text-[13px] font-bold"><span>{label}</span><span className="mono text-[var(--accent)]">{val}</span></div><div className="h-2.5 bg-[#0a1a10] rounded-full mt-1.5 overflow-hidden"><div className="h-full bg-[var(--accent)] rounded-full" style={{width:`${val}%`}}/></div></div>)}<button onClick={()=>go('Join')} className="w-full min-h-[48px] mt-4 rounded-full bg-[#FFC107] text-black font-black text-sm">Join This Team →</button></aside>
      </div>}
      {tab==='Stats' && <div className="mt-4"><h3 className="font-black text-xl">Top scorers — {teamKey}</h3><div className="space-y-2 mt-3">{scorers.map((p,i)=> <div key={p.id} className="bg-[var(--surface)] border border-[var(--line)] rounded-[20px] p-4 flex items-center gap-3"><span className="font-black text-[20px] text-[#FFC107] w-8">{i+1}</span><span className="w-11 h-11 rounded-full grid place-items-center font-black shrink-0" style={{background:p.color, color:p.color==='#FFC107'?'#111':'#fff'}}>{p.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</span><div className="flex-1 min-w-0"><b className="block truncate">{p.name}</b><span className="text-[13px] text-[var(--muted)]">{p.pos} • #{p.num} • {p.grade} • {p.assists} assists</span></div><div className="text-right"><b className="text-[22px]">{p.goals}</b><div className="text-[10px] text-[var(--muted)] font-bold">GOALS</div></div></div>)}</div><div className="grid sm:grid-cols-3 gap-3 mt-4"><div className="bg-white text-[#0a1a10] rounded-[20px] p-4"><b className="text-[24px]">{list.reduce((s,p)=>s+p.goals,0)}</b><p className="text-[13px] text-[#4a5a50]">Team goals this season</p></div><div className="bg-white text-[#0a1a10] rounded-[20px] p-4"><b className="text-[24px]">{list.reduce((s,p)=>s+p.assists,0)}</b><p className="text-[13px] text-[#4a5a50]">Team assists this season</p></div><div className="bg-white text-[#0a1a10] rounded-[20px] p-4"><b className="text-[24px]">{(list.reduce((s,p)=>s+p.rating,0)/list.length).toFixed(1)}</b><p className="text-[13px] text-[#4a5a50]">Average squad rating</p></div></div></div>}
      {tab==='Fixtures' && <div className="mt-4">{teamKey==='Boys' ? <div className="space-y-2">{boysFixtures.map((f,i)=> <div key={i} className="bg-[var(--surface)] border border-[var(--line)] rounded-[20px] p-4"><div className="flex justify-between gap-2 flex-wrap"><b>vs {f.opp}</b><span className="mono text-[12px] text-[var(--accent)]">{f.date}</span></div><p className="text-[13px] text-[var(--muted)] mt-1">{f.venue} • {f.comp}</p><p className="text-[13px] mt-1">{f.note}</p></div>)}</div> : <div className="space-y-2">{girlsFixtures.map((f,i)=> <div key={i} className="bg-[var(--surface)] border border-[var(--line)] rounded-[20px] p-4"><div className="flex justify-between gap-2 flex-wrap"><b>vs {f.opp}</b><span className="mono text-[12px] text-[var(--accent)]">{f.date}</span></div><p className="text-[13px] text-[var(--muted)] mt-1">{f.venue} • {f.comp}</p><p className="text-[13px] mt-1">{f.note}</p></div>)}</div>}</div>}
    </div>;
  }

  const tacticsBlock = <div className="grid lg:grid-cols-[1fr_300px] gap-4 items-start">
    <div>
      <div className="flex flex-wrap justify-between gap-3 items-end"><div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">TACTICS BOARD • DRAG PLAYERS • TOUCH READY</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Shape the game.</h2></div><span className="mono text-xs bg-[#122a1b] border border-[var(--line)] px-3 py-2 rounded-full">FORMATION {formation} • {side==='Home'?'CHEBUKWABI JS':'OPPONENT'} • {tacticalTeam.toUpperCase()}</span></div>
      <div className="flex flex-wrap gap-2 mt-4"><button onClick={()=>setTacticalTeam('Boys')} className={`min-h-[48px] px-5 rounded-full font-black ${tacticalTeam==='Boys'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Boys Team</button><button onClick={()=>setTacticalTeam('Girls')} className={`min-h-[48px] px-5 rounded-full font-black ${tacticalTeam==='Girls'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Girls Team</button></div>
      <div className="flex flex-wrap gap-2 mt-2">{(['4-3-3','4-4-2','3-5-2','4-2-3-1'] as FormationKey[]).map(f=> <button key={f} onClick={()=>setFormation(f)} className={`min-h-[48px] px-5 rounded-full font-black ${formation===f?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>{f}</button>)}<button onClick={()=>setSide(side==='Home'?'Away':'Home')} className="min-h-[48px] px-5 rounded-full bg-white text-black font-bold flex items-center gap-2"><Shuffle size={16}/> {side==='Home'?'Switch to Opponent':'Show Chebukwabi JS'}</button><button onClick={()=>setPositions(formations[formation])} className="min-h-[48px] px-5 rounded-full bg-[#122a1b] border border-[var(--line)] font-bold flex items-center gap-2"><RefreshCcw size={16}/> Reset</button><button onClick={()=>setShowAvg(!showAvg)} className={`min-h-[48px] px-5 rounded-full font-bold border ${showAvg?'bg-[#FFC107] text-black border-[#FFC107]':'bg-[#122a1b] border-[var(--line)]'}`}>Average positions: {showAvg?'On':'Off'}</button></div>
      <div ref={pitchRef} onPointerMove={onPitchPointer} onPointerUp={()=>setDragId(null)} onPointerLeave={()=>setDragId(null)} className="pitch-lines relative mt-4 rounded-[24px] border-2 border-white/40 bg-[#0A5C36] overflow-hidden touch-none select-none" style={{aspectRatio:'4 / 5', maxHeight:720}}>
        <div className="absolute inset-x-[12%] top-[4%] h-[14%] border-2 border-white/50 border-t-0"/><div className="absolute inset-x-[32%] top-[4%] h-[6%] border-2 border-white/50 border-t-0"/><div className="absolute inset-x-[12%] bottom-[4%] h-[14%] border-2 border-white/50 border-b-0"/><div className="absolute inset-x-[32%] bottom-[4%] h-[6%] border-2 border-white/50 border-b-0"/><div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-white/40"/><div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[38%] aspect-square rounded-full border-2 border-white/40"/><div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"/>
        <div className="absolute top-2 left-3 mono text-[10px] bg-black/40 px-2 py-1 rounded-full">{side==='Home'?`CJS ${tacticalTeam.toUpperCase()} ATTACK →`:'OPPONENT ATTACK →'}</div>
        {showAvg && positions.map((p,i)=> <div key={`avg-${i}`} className="absolute w-3 h-3 rounded-full border-2 border-dashed border-white/70 pointer-events-none" style={{left:`calc(${p.x}% - 6px)`, top:`calc(${p.y}% + 18px)`}}/>)}
        {positions.map((p,i)=>{ const pl = playerByNum(tacticalTeam, p.num); return (<button key={i} onPointerDown={e=>{ (e.target as HTMLElement).setPointerCapture(e.pointerId); setDragId(i); }} onPointerUp={()=>setDragId(null)} className={`absolute z-10 w-[58px] h-[58px] sm:w-[64px] sm:h-[64px] rounded-full grid place-items-center font-black text-[14px] border-[3px] shadow-xl transition-transform ${dragId===i?'scale-110':''}`} style={{left:`calc(${p.x}% - 30px)`, top:`calc(${p.y}% - 30px)`, background: side==='Home' ? '#0A5C36' : '#b91c1c', color: side==='Home' ? '#FFC107' : '#fff', borderColor: side==='Home' ? '#FFC107' : '#fff', cursor:'grab'}} aria-label={`Drag ${p.label} ${p.role} ${pl?.name || ''}`}>{p.num}<span className="absolute -bottom-7 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-bold bg-black/70 px-1.5 py-0.5 rounded text-white">{side==='Home' ? pl?.name.split(' ').slice(-1)[0] : p.role} • {p.label}</span></button>);})}
      </div>
      <p className="text-[13px] text-[var(--muted)] mt-3 text-center">Tip: press and drag any dot. Green + gold is Chebukwabi JS. Red + white is the opponent. Player names show under each dot.</p>
      <div className="bg-[var(--surface)] border border-[var(--line)] rounded-[22px] p-4 mt-3"><h3 className="font-black">Starting XI — {formation} • {tacticalTeam}</h3><div className="grid sm:grid-cols-2 gap-2 mt-3">{positions.map((p,i)=>{ const pl=playerByNum(tacticalTeam, p.num); return <div key={i} className="flex justify-between gap-2 bg-[#0a1a10] rounded-xl px-3 py-2 text-sm"><span><b>#{pl?.num}</b> {pl?.name}</span><span className="text-[var(--muted)]">{p.label} • {pl?.grade}</span></div>; })}</div></div>
    </div>
    <aside className="space-y-4"><div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black flex gap-2 items-center"><Gauge size={18} className="text-[var(--accent)]"/> Shape notes</h3><ul className="text-[14px] text-[var(--muted)] leading-relaxed mt-3 space-y-3"><li><b className="text-white">In possession:</b> Full-backs push high, one midfielder drops to build a back three.</li><li><b className="text-white">Out of possession:</b> Front three narrow the pitch; midfield stays compact.</li><li><b className="text-white">Weak side:</b> Watch the space behind the advanced full-back on the counter.</li></ul></div><div className="bg-[#FFC107] text-black rounded-[24px] p-5"><h3 className="font-black">Average positions</h3><p className="text-[13px] font-medium mt-2 leading-relaxed">The {formation} is most compact between the lines. The striker averages 8m higher than in the last match.</p><div className="grid grid-cols-3 gap-2 mt-4 text-center"><div className="bg-black/10 rounded-xl py-2"><b>42m</b><div className="text-[11px] font-bold">TEAM HEIGHT</div></div><div className="bg-black/10 rounded-xl py-2"><b>31m</b><div className="text-[11px] font-bold">WIDTH</div></div><div className="bg-black/10 rounded-xl py-2"><b>11</b><div className="text-[11px] font-bold">PLAYERS</div></div></div></div></aside>
  </div>;

  const analysisBlock = <div className="grid lg:grid-cols-[1fr_360px] gap-4">
    <div>
      <div className="flex flex-wrap gap-3 items-center"><button onClick={()=>{setAnalysisTeam('Boys'); setAnalysisId('B-CJS-NAM');}} className={`min-h-[48px] px-5 rounded-full font-black ${analysisTeam==='Boys'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Boys Matches</button><button onClick={()=>{setAnalysisTeam('Girls'); setAnalysisId('G-CJS-NAM');}} className={`min-h-[48px] px-5 rounded-full font-black ${analysisTeam==='Girls'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Girls Matches</button></div>
      <div className="flex flex-wrap gap-3 items-end justify-between mt-4"><div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">MATCH CENTRE • {analysisTeam.toUpperCase()} • CHEBUKWABI JS</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">{match.home} <span className="text-[var(--muted)]">vs</span> {match.away}</h2><p className="text-[13px] text-[var(--muted)] mt-1 flex items-center gap-1"><MapPin size={13}/> {match.comp} • {match.venue}</p></div><label className="relative block w-full sm:w-[340px]"><span className="text-[11px] font-bold text-[var(--muted)]">SELECT LAST MATCH — {analysisTeam.toUpperCase()}</span><select value={analysisId} onChange={e=>setAnalysisId(e.target.value)} className="w-full mt-1 min-h-[52px] bg-[var(--surface)] border border-[var(--line)] rounded-2xl px-4 pr-10 text-[15px] font-bold outline-none">{allMatches.filter(m=>m.team===analysisTeam).map(m=><option key={m.id} value={m.id}>{m.home} vs {m.away} — {m.score}</option>)}</select><ChevronDown className="absolute right-4 bottom-4 pointer-events-none" size={18}/></label></div>
      <div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 mt-4">
        <div className="flex items-center justify-between gap-3"><div className="flex items-center gap-3"><Badge short={match.shortH} color={match.homeColor} size={48}/><div><b>{match.home}</b><div className="text-xs text-[var(--muted)]">HOME</div></div></div><div className="text-center"><div className="text-[34px] font-black leading-none">{match.score}</div><div className="text-[11px] mono text-[var(--accent)] mt-1">{match.status}</div></div><div className="flex items-center gap-3 text-right"><div><b>{match.away}</b><div className="text-xs text-[var(--muted)]">AWAY</div></div><Badge short={match.shortA} color={match.awayColor} size={48}/></div></div>
        <div className="mt-5"><div className="flex justify-between mono font-bold text-sm"><span className="text-[var(--accent)]">{match.poss[0]}%</span><span className="text-[var(--muted)]">POSSESSION</span><span>{match.poss[1]}%</span></div><div className="flex h-4 rounded-full overflow-hidden bg-white/10 mt-2"><div className="bg-[var(--accent)]" style={{width:`${match.poss[0]}%`}}/><div className="bg-white" style={{width:`${match.poss[1]}%`}}/></div></div>
        <div className="mt-2"><StatRow label="Expected Goals (xG)" home={match.xg[0]} away={match.xg[1]} homeMax={3.5} awayMax={3.5}/><StatRow label="Shots" home={match.shots[0]} away={match.shots[1]} homeMax={20} awayMax={20}/><StatRow label="Shots on Target" home={match.onTarget[0]} away={match.onTarget[1]} homeMax={10} awayMax={10}/><StatRow label="Pass Accuracy" home={match.passAcc[0]} away={match.passAcc[1]} homeMax={100} awayMax={100} suffix="%"/><StatRow label="Corners" home={match.corners[0]} away={match.corners[1]} homeMax={10} awayMax={10}/><StatRow label="Fouls" home={match.fouls[0]} away={match.fouls[1]} homeMax={20} awayMax={20}/></div>
      </div>
      <div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 mt-4"><div className="flex justify-between items-center"><h3 className="font-black flex items-center gap-2"><Activity size={18} className="text-[var(--accent)]"/> Momentum</h3><span className="mono text-[11px] text-[var(--muted)]">0′ — 90′</span></div><canvas ref={canvasRef} className="w-full h-[180px] mt-3" aria-label="Momentum chart showing which team dominated over time"/><div className="flex justify-between mono text-[11px] text-[var(--muted)]"><span>0′</span><span>15′</span><span>30′</span><span>45′</span><span>60′</span><span>75′</span><span>90′</span></div></div>
    </div>
    <aside className="space-y-4"><div className="bg-[#FFC107] text-black rounded-[24px] p-5"><h3 className="font-black flex items-center gap-2"><Trophy size={18}/> Man of the Match</h3><p className="text-[15px] font-bold mt-2 leading-snug">{match.motm}</p></div><div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black text-lg">Key Moments</h3><p className="text-[13px] text-[var(--muted)]">Goals, cards and substitutions.</p><div className="mt-4 space-y-0">{match.moments.map((mo,i)=> <div key={i} className="flex gap-3 pb-5 relative"><div className="flex flex-col items-center"><span className="w-3 h-3 rounded-full shrink-0 mt-1" style={{background:mo.color}}/><span className="w-px flex-1 bg-white/15 mt-1"/></div><div className="min-w-0"><div className="flex gap-2 items-center flex-wrap"><span className="mono text-xs font-bold text-[var(--accent)]">{mo.min}</span><span className="text-[10px] font-black bg-white/10 px-2 py-0.5 rounded-full">{mo.type.toUpperCase()} • {mo.team}</span></div><p className="text-[14px] leading-snug mt-1.5">{mo.label}</p></div></div>)}</div><div className="bg-[#0a1a10] rounded-2xl p-4 mt-2"><p className="font-bold text-sm flex gap-2"><Zap size={16} className="text-[var(--accent)]"/> Coach verdict</p><p className="text-[13px] text-[var(--muted)] leading-relaxed mt-2">{match.verdict}</p></div></div></aside>
  </div>;

  const dashboardBlock = <div>
    <div className="flex flex-wrap items-end justify-between gap-3 mb-4"><div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">CHEBUKWABI JS • SEASON OVERVIEW • BOYS + GIRLS</p><h2 className="text-[clamp(26px,4vw,42px)] font-black leading-[0.95] mt-1">Our season,<br/>our team.</h2></div><div className="flex gap-2"><span className="px-3 py-2 rounded-full bg-[#122a1b] border border-[var(--line)] text-xs font-bold flex items-center gap-1.5"><CalendarDays size={14}/> SUB-COUNTY GAMES</span><span className="px-3 py-2 rounded-full bg-[#FFC107] text-black text-xs font-black">LEAGUE {season.position}</span></div></div>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {[{label:'PLAYED', value:String(season.played), sub:'This season'},{label:'WON', value:String(season.won), sub:'3 drawn • 1 lost'},{label:'GOALS FOR', value:String(season.gf), sub:'Against: 11'},{label:'LEAGUE POSITION', value:season.position, sub:'Sub-County table'},{label:'TOP SCORER • BOYS', value:'Khaemba', sub:'11 goals • No. 7'},{label:'TOP SCORER • GIRLS', value:'Chebet', sub:'10 goals • No. 9'},{label:'GOAL DIFFERENCE', value:'+18', sub:'29 scored • 11 conceded'},{label:'SQUAD', value:'36', sub:'18 Boys • 18 Girls'}].map(s=> <div key={s.label} className="bg-[var(--surface)] border border-[var(--line)] rounded-[22px] p-4 min-w-0"><div className="text-[11px] mono font-bold text-[var(--accent)]">{s.label}</div><div className="text-[clamp(20px,5vw,28px)] font-black leading-tight mt-1 break-words [overflow-wrap:anywhere]">{s.value}</div><div className="text-[12px] text-[var(--muted)] break-words">{s.sub}</div></div>)}
    </div>
    <div className="grid lg:grid-cols-3 gap-4 mt-4">
      <section className="lg:col-span-2 bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><div className="flex justify-between items-center"><h3 className="font-black text-lg flex items-center gap-2"><TrendingUp size={18} className="text-[var(--accent)]"/> Last 5 results — Chebukwabi JS</h3><span className="mono text-[11px] text-[var(--muted)]">FORM</span></div><div className="mt-4 space-y-2">{lastFive.map((r,i)=> <div key={i} className="flex items-center justify-between gap-3 bg-[#0a1a10] rounded-2xl px-4 py-3"><div className="min-w-0"><b className="block truncate">vs {r.opp}</b><span className="text-xs text-[var(--muted)]">{r.where}</span></div><div className="flex items-center gap-3 shrink-0"><span className="mono font-bold">{r.score}</span><span className="w-8 h-8 rounded-full grid place-items-center text-xs font-black" style={{background: r.result==='W'?'#FFC107':r.result==='D'?'#fff':'#ff5a5a', color:'#0a140d'}}>{r.result}</span></div></div>)}</div></section>
      <section className="bg-[#FFC107] text-black rounded-[24px] p-5"><p className="mono text-[11px] font-bold tracking-widest">NEXT MATCH</p><h3 className="font-black text-[24px] leading-tight mt-2">vs {nextMatch.opp}</h3><p className="text-[13px] font-semibold opacity-80 mt-1 flex items-center gap-1"><MapPin size={14}/> {nextMatch.venue} • {nextMatch.date}</p><p className="text-[13px] font-medium mt-3 leading-relaxed">{nextMatch.comp}. {nextMatch.note}</p><button onClick={()=>go('Join')} className="w-full min-h-[48px] mt-4 rounded-full bg-black text-white font-bold text-sm">Join The Team →</button></section>
    </div>
    {joinRequests.length>0 && <div className="bg-white text-[#0a1a10] rounded-[24px] p-5 mt-4"><h3 className="font-black flex items-center gap-2"><Users size={18}/> New Join Requests ({joinRequests.length})</h3><p className="text-[13px] text-[#4a5a50]">Saved from the Join Us form. The coach can welcome these players.</p><div className="flex flex-wrap gap-2 mt-3">{joinRequests.map(j=> <span key={j.id} className="bg-[#fff3c4] border border-[#FFC107] rounded-full px-3 py-2 text-[13px] font-bold">{j.name} • {j.gender} • {j.grade} • {j.pos}{j.phone?` • ${j.phone}`:''}{j.guardianPhone?` • Guardian: ${j.guardianPhone}`:''}</span>)}</div></div>}
    <div className="mt-5"><h3 className="font-black mb-2">Boys — recent matches</h3>{matchCardList(boysMatches)}</div>
    <div className="mt-4"><h3 className="font-black mb-2">Girls — recent matches</h3>{matchCardList(girlsMatches)}</div>
  </div>;
  const playersBlock = <div>
      <p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">SQUAD MANAGEMENT • COACH ONLY</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Squad Management</h2>
      <div className="flex flex-wrap gap-2 mt-4"><button onClick={()=>setShowAddPlayer(!showAddPlayer)} className="min-h-[48px] px-5 rounded-full bg-[#FFC107] text-black font-black text-sm flex items-center gap-2"><Plus size={18}/> Add Player</button><span className="min-h-[48px] px-4 rounded-full bg-[#122a1b] border border-[var(--line)] text-sm font-bold flex items-center">Boys: Coach Galvin • Captain: Ian Wanjala</span><span className="min-h-[48px] px-4 rounded-full bg-[#122a1b] border border-[var(--line)] text-sm font-bold flex items-center">Girls: Coach Mary • Captain: Grace Wanjiru</span></div>
      {showAddPlayer && <div className="bg-[var(--surface)] border border-[var(--accent)] rounded-[22px] p-4 mt-3 space-y-3"><h3 className="font-black">Add a Chebukwabi JS player</h3><label className="block text-sm font-bold">Team<select value={newTeam} onChange={e=>setNewTeam(e.target.value as TeamKey)} className="w-full mt-1 min-h-[48px] bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3"><option>Boys</option><option>Girls</option></select></label><label className="block text-sm font-bold">Full name<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="e.g. Kevin Wekesa" className="w-full mt-1 min-h-[48px] bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3 outline-none"/></label><div className="grid grid-cols-3 gap-2"><label className="block text-sm font-bold">Position<select value={newPos} onChange={e=>setNewPos(e.target.value)} className="w-full mt-1 min-h-[48px] bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3"><option>GK</option><option>DF</option><option>MF</option><option>FW</option></select></label><label className="block text-sm font-bold">Shirt No.<input value={newNum} onChange={e=>setNewNum(e.target.value)} inputMode="numeric" placeholder="19" className="w-full mt-1 min-h-[48px] bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3 outline-none"/></label><label className="block text-sm font-bold">Class<select value={newGrade} onChange={e=>setNewGrade(e.target.value)} className="w-full mt-1 min-h-[48px] bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3"><option>Grade 7</option><option>Grade 8</option><option>Grade 9</option></select></label></div><label className="block text-sm font-bold">Note (optional)<input value={newNote} onChange={e=>setNewNote(e.target.value)} placeholder="e.g. Strong in the air" className="w-full mt-1 min-h-[48px] bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3 outline-none"/></label><button onClick={addPlayer} disabled={busy} className="w-full min-h-[48px] rounded-full bg-[#FFC107] text-black font-black disabled:opacity-50">{busy?'Saving…':'Save player to squad'}</button></div>}
      {saveMessage && <p className="mt-3 text-sm bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3 py-2" role="status">{saveMessage}</p>}
      {savedPlayers.length>0 && <div className="mt-4 space-y-2"><h3 className="font-black text-sm">Saved squad additions</h3>{savedPlayers.map(sp=> <div key={sp.id} className="flex justify-between items-center bg-[var(--surface)] border border-[var(--line)] rounded-xl px-3 py-2 text-sm"><span>#{sp.num} {sp.name} • {sp.team} • {sp.pos} • {sp.grade}</span><button onClick={()=>deletePlayer(sp.id)} disabled={busy} className="min-h-[40px] px-3 rounded-full bg-white/10 font-bold flex items-center gap-1"><Trash2 size={14}/> Remove</button></div>)}</div>}
      <div className="mt-4"><h3 className="font-black">Boys squad — {players.length} players</h3><div className="flex flex-wrap gap-2 mt-2">{players.map(p=> <span key={p.id} className="bg-[var(--surface)] border border-[var(--line)] rounded-full px-3 py-1.5 text-[13px]">#{p.num} {p.name} • {p.pos} • {p.goals}G</span>)}</div><h3 className="font-black mt-4">Girls squad — {girlsPlayers.length} players</h3><div className="flex flex-wrap gap-2 mt-2">{girlsPlayers.map(p=> <span key={p.id} className="bg-[var(--surface)] border border-[var(--line)] rounded-full px-3 py-1.5 text-[13px]">#{p.num} {p.name} • {p.pos} • {p.goals}G</span>)}</div></div>
  </div>;
  const notesBlock = <div className="grid lg:grid-cols-[1fr_360px] gap-4 items-start"><div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">COACH NOTES • CHEBUKWABI JS</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Plan the next match.</h2><p className="text-[14px] text-[var(--muted)] mt-2">Add notes for the next match, strengths, weaknesses and the set-piece plan. Saved notes stay for the next visit.</p><div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 mt-4 space-y-3"><h3 className="font-black flex items-center gap-2"><NotebookPen size={18} className="text-[var(--accent)]"/> Add a coach note</h3><label className="block text-sm font-bold">Type<select value={noteKind} onChange={e=>setNoteKind(e.target.value)} className="w-full mt-1 min-h-[52px] bg-[#0a1a10] border border-[var(--line)] rounded-2xl px-4"><option>Next match</option><option>Strength</option><option>Weakness</option><option>Set-piece plan</option><option>General</option></select></label><label className="block text-sm font-bold">Title<input value={noteTitle} onChange={e=>setNoteTitle(e.target.value)} placeholder="e.g. Vs Namwela JS — first 15 minutes" className="w-full mt-1 min-h-[52px] bg-[#0a1a10] border border-[var(--line)] rounded-2xl px-4 outline-none"/></label><label className="block text-sm font-bold">Note<textarea value={noteBody} onChange={e=>setNoteBody(e.target.value)} rows={4} placeholder="What should the team do? Who marks whom? What is the set-piece routine?" className="w-full mt-1 bg-[#0a1a10] border border-[var(--line)] rounded-2xl px-4 py-3 outline-none resize-y"/></label><button onClick={addNote} disabled={busy} className="w-full min-h-[52px] rounded-full bg-[#FFC107] text-black font-black disabled:opacity-50">{busy?'Saving…':'Save coach note'}</button>{noteMessage && <p className="text-sm" role="status">{noteMessage}</p>}</div><div className="mt-4 space-y-3"><h3 className="font-black">Your saved notes {savedNotes.length>0 && <span className="text-[var(--accent)]">({savedNotes.length})</span>}</h3>{savedNotes.length===0 && <p className="text-sm text-[var(--muted)] bg-[var(--surface)] border border-[var(--line)] rounded-2xl p-4">No saved notes yet. Use the form above — your first note will appear here.</p>}{savedNotes.map(n=> <article key={n.id} className="bg-[var(--surface)] border border-[var(--line)] rounded-[22px] p-5"><div className="flex justify-between gap-3 items-start"><span className="text-[11px] font-black bg-[#FFC107] text-black px-2 py-1 rounded-full">{n.kind.toUpperCase()}</span><button onClick={()=>deleteNote(n.id)} disabled={busy} className="min-h-[40px] px-3 rounded-full bg-white/10 text-sm font-bold flex items-center gap-1"><Trash2 size={14}/> Remove</button></div><h4 className="font-black text-lg mt-3 leading-tight">{n.title}</h4><p className="text-[14px] text-[var(--muted)] leading-relaxed mt-1 whitespace-pre-wrap">{n.body}</p></article>)}</div></div><aside className="space-y-4"><div className="bg-[#FFC107] text-black rounded-[24px] p-5"><h3 className="font-black">Next match focus</h3><p className="text-[13px] font-medium mt-2 leading-relaxed">Vs {nextMatch.opp} • {nextMatch.date} • {nextMatch.venue}. Start fast, press the first pass, and protect the space behind the full-backs.</p></div><div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black flex gap-2 items-center"><Target size={18} className="text-[var(--accent)]"/> Starter examples</h3><p className="text-[13px] text-[var(--muted)] mt-2">Use these as a starting point — add your own notes on the left.</p><div className="space-y-3 mt-3">{starterNotes.map((n,i)=> <div key={i} className="bg-[#0a1a10] rounded-2xl p-4"><span className="mono text-[11px] text-[var(--accent)] font-bold">{n.kind.toUpperCase()}</span><h4 className="font-black mt-1 leading-tight">{n.title}</h4><p className="text-[13px] text-[var(--muted)] leading-relaxed mt-1">{n.body}</p></div>)}</div></div></aside></div>;
  const attendanceBlock = <div>
    <p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">ATTENDANCE TRACKER • COACH ONLY</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">{t.attendance} • Mahudhurio</h2><p className="text-[14px] text-[var(--muted)] mt-2">Tick who is here. Tap a name to change Present / Absent, then save. Saved attendance stays for the coach.</p>
    <div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 mt-4">
      <div className="flex flex-wrap gap-2"><button onClick={()=>{setAttTeam('Boys'); setPresentIds(new Set(players.map(p=>p.id)));}} className={`min-h-[48px] px-5 rounded-full font-black ${attTeam==='Boys'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Boys</button><button onClick={()=>{setAttTeam('Girls'); setPresentIds(new Set(girlsPlayers.map(p=>p.id)));}} className={`min-h-[48px] px-5 rounded-full font-black ${attTeam==='Girls'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Girls</button></div>
      <label className="block text-sm font-bold mt-4">Training / Match date<input type="date" value={attDate} onChange={e=>setAttDate(e.target.value)} className="w-full sm:w-[280px] mt-1 min-h-[52px] bg-[#0a1a10] border border-[var(--line)] rounded-2xl px-4"/></label>
      <div className="flex flex-wrap gap-2 mt-3"><button onClick={()=>setPresentIds(new Set((attTeam==='Boys'?players:girlsPlayers).map(p=>p.id)))} className="min-h-[44px] px-4 rounded-full bg-white text-black font-bold text-sm">All Present</button><button onClick={()=>setPresentIds(new Set())} className="min-h-[44px] px-4 rounded-full bg-[#122a1b] border border-[var(--line)] font-bold text-sm">Clear All</button><span className="min-h-[44px] px-4 rounded-full bg-[#FFC107] text-black font-black text-sm flex items-center">{presentIds.size} / {(attTeam==='Boys'?players:girlsPlayers).length} present</span></div>
      <div className="grid sm:grid-cols-2 gap-2 mt-4">{(attTeam==='Boys'?players:girlsPlayers).map(p=>{ const present=presentIds.has(p.id); return <button key={p.id} onClick={()=>setPresentIds(prev=>{ const n=new Set(prev); if(n.has(p.id)) n.delete(p.id); else n.add(p.id); return n; })} aria-pressed={present} className={`min-h-[56px] rounded-2xl px-4 flex items-center justify-between gap-2 text-left font-bold ${present?'bg-[#0A5C36] text-white border border-[#FFC107]':'bg-[#0a1a10] border border-[var(--line)] text-[var(--muted)]'}`}><span>#{p.num} {p.name} • {p.pos}</span><span className="text-[12px] px-2 py-1 rounded-full bg-white/15">{present?'✓ Present':'Absent'}</span></button>; })}</div>
      <button onClick={saveAttendance} disabled={attBusy} className="w-full min-h-[56px] mt-4 rounded-full bg-[#FFC107] text-black font-black disabled:opacity-50">{attBusy?'Saving attendance…':'Save Attendance'}</button>
      {attResult && <div role="status" className="mt-3 bg-[#0a1a10] border border-[var(--line)] rounded-xl px-3 py-2 text-sm">Saved: <b>{attResult.saved}</b> • Remaining: <b>{attResult.remaining}</b>{attResult.error && <span className="block text-[#ff9a9a]">Error: {attResult.error}</span>}{attResult.reloadError && <span className="block">Reload note: {attResult.reloadError}</span>}{!attResult.error && <span className="block text-[#FFC107]">Attendance saved for {attDate}.</span>}</div>}
    </div>
    {attendanceRecs.length>0 && <div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 mt-4"><h3 className="font-black">Saved attendance records ({attendanceRecs.length})</h3><div className="flex flex-wrap gap-2 mt-3">{attendanceRecs.slice(-24).map(a=> <span key={a.id} className="bg-[#0a1a10] rounded-full px-3 py-1.5 text-[12px]">{a.date} • {a.name} • {a.status}</span>)}</div></div>}
  </div>;
  const myProfileBlock = <div>
    <p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">PLAYER PORTAL • NO PASSWORD</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">{t.myProfile} • {t.myStats}</h2><p className="text-[14px] text-[var(--muted)] mt-2">Pick your team and name to see your stats. This is for players to check their own progress.</p>
    <div className="flex flex-wrap gap-2 mt-4"><button onClick={()=>{setMyTeam('Boys'); setMyPlayerId(7);}} className={`min-h-[48px] px-5 rounded-full font-black ${myTeam==='Boys'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Boys</button><button onClick={()=>{setMyTeam('Girls'); setMyPlayerId(102);}} className={`min-h-[48px] px-5 rounded-full font-black ${myTeam==='Girls'?'bg-[#FFC107] text-black':'bg-[#122a1b] border border-[var(--line)]'}`}>Girls</button></div>
    <label className="relative block mt-4 max-w-[480px]"><span className="text-[11px] font-bold text-[var(--muted)]">PICK YOUR NAME / CHAGUA JINA LAKO</span><select value={myPlayerId} onChange={e=>setMyPlayerId(Number(e.target.value))} className="w-full mt-1 min-h-[56px] bg-[var(--surface)] border border-[var(--line)] rounded-2xl px-4 pr-10 font-bold"><option value={0} disabled>Select…</option>{myPool.map(p=><option key={p.id} value={p.id}>{p.name} — #{p.num} {p.pos} • {p.grade}</option>)}</select><ChevronDown className="absolute right-4 bottom-4 pointer-events-none" size={18}/></label>
    <div className="grid lg:grid-cols-3 gap-4 mt-4">
      <div className="lg:col-span-2 bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><div className="flex gap-3 items-center"><span className="w-[72px] h-[72px] rounded-full grid place-items-center font-black text-lg" style={{background:myPlayer.color, color:myPlayer.color==='#FFC107'?'#111':'#fff'}}>{myPlayer.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</span><div><h3 className="font-black text-[24px] leading-tight">{myPlayer.name}</h3><p className="text-[13px] text-[var(--muted)]">{myPlayer.team} • {myPlayer.pos} • #{myPlayer.num} • {myPlayer.grade}</p>{myPlayer.note && <p className="text-sm font-bold text-[#FFC107] mt-1">{myPlayer.note}</p>}</div><div className="ml-auto text-right"><div className="text-[28px] font-black text-[var(--accent)]">{myPlayer.rating.toFixed(1)}</div><div className="text-[10px] text-[var(--muted)] font-bold">RATING</div></div></div>
      <div className="grid grid-cols-4 gap-2 mt-5 text-center"><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block text-xl">{myPlayer.goals}</b><span className="text-[10px] text-[var(--muted)] font-bold">GOALS</span></div><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block text-xl">{myPlayer.assists}</b><span className="text-[10px] text-[var(--muted)] font-bold">ASSISTS</span></div><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block text-xl">{myPlayer.xg}</b><span className="text-[10px] text-[var(--muted)] font-bold">xG</span></div><div className="bg-[#0a1a10] rounded-xl py-3"><b className="block text-xl">{myPlayer.pass}%</b><span className="text-[10px] text-[var(--muted)] font-bold">PASS</span></div></div>
      <h4 className="font-black mt-5">Your strengths</h4>{([['Pace',myPlayer.pace],['Passing',myPlayer.passing],['Shooting',myPlayer.shooting],['Defending',myPlayer.defending],['Dribbling',myPlayer.dribbling]] as [string,number][]).map(([l,v])=> <div key={l} className="py-2"><div className="flex justify-between text-[13px] font-bold"><span>{l}</span><span className="mono text-[var(--accent)]">{v}</span></div><div className="h-2.5 bg-[#0a1a10] rounded-full mt-1 overflow-hidden"><div className="h-full bg-[var(--accent)]" style={{width:`${v}%`}}/></div></div>)}</div>
      <aside className="bg-[#FFC107] text-black rounded-[24px] p-5 h-fit"><h3 className="font-black flex items-center gap-2"><Sparkles size={18}/> Keep growing</h3><p className="text-[13px] font-medium mt-2 leading-relaxed">Discipline • Teamwork • Excellence. Train hard, help your teammate, and listen to the coach. Your rating grows with effort.</p><button onClick={()=>setPortalTab('Training')} className="w-full min-h-[48px] mt-4 rounded-full bg-black text-white font-bold text-sm">See Training Schedule →</button></aside>
    </div>
  </div>;

  const donateBlock = <div>
    <section className="bg-[#FFC107] text-black rounded-[28px] p-5 sm:p-8 overflow-hidden">
      <p className="mono text-[11px] font-bold tracking-[0.2em]">SUPPORT CHEBUKWABI JS • SAIDIA TIMU</p>
      <h2 className="text-[clamp(28px,5vw,48px)] font-black leading-[0.95] mt-2">Support Chebukwabi JS<br/>Donate via Pochi La Biashara</h2>
      <p className="text-[15px] font-medium mt-3 max-w-[640px]">Your donation buys balls, kits, transport and lunch for our boys and girls.</p>
      <div className="grid lg:grid-cols-[1fr_360px] gap-5 mt-6 items-start">
        <div className="bg-black text-white rounded-[24px] p-5 text-center"><p className="text-[12px] font-bold tracking-widest text-[#FFC107]">POCHI LA BIASHARA • M-PESA</p><div className="text-[clamp(38px,10vw,64px)] font-black tracking-tight leading-none mt-2">0724711658</div><p className="font-bold mt-2">Name: Chebukwabi JS</p><p className="text-[13px] text-white/70 mt-1">Send to this number from M-PESA. Keep your M-PESA message as your receipt.</p>
          <div className="mt-4"><p className="text-[13px] font-bold">Quick amount / Chagua kiasi</p><div className="flex flex-wrap gap-2 justify-center mt-2">{[100,200,500,1000,5000].map(a=> <button key={a} onClick={()=>setDonateAmount(a)} className={`min-h-[48px] px-5 rounded-full font-black ${donateAmount===a?'bg-[#FFC107] text-black':'bg-white/10 border border-white/20'}`}>KSh {a.toLocaleString()}</button>)}</div><p className="text-[13px] mt-3">Selected amount: <b className="text-[#FFC107]">KSh {donateAmount.toLocaleString()}</b> — send this amount to 0724711658 in M-PESA.</p></div>
          <button onClick={()=>setDonated(true)} className="w-full min-h-[56px] mt-4 rounded-full bg-[#FFC107] text-black font-black text-[16px] flex items-center justify-center gap-2"><HandCoins size={18}/> I Have Donated • Nimeshachangia</button>
          {donated && <p role="status" className="mt-3 bg-[#0A5C36] text-white rounded-xl px-3 py-3 font-bold">Asante! Thank you for supporting Chebukwabi JS. Your donation means so much to our boys and girls. / Asante sana!</p>}
        </div>
        <div className="space-y-3"><div className="bg-white rounded-[22px] p-5"><h3 className="font-black">How to donate • Jinsi ya kuchangia</h3><ol className="mt-3 space-y-2 text-[14px] font-medium list-decimal pl-5"><li>Go to M-PESA</li><li>Send Money / Pochi La Biashara</li><li>Enter <b>0724711658</b></li><li>Enter Amount — e.g. KSh {donateAmount.toLocaleString()}</li><li>Enter PIN and confirm</li></ol></div><div className="bg-black text-white rounded-[22px] p-5"><div className="flex justify-between text-sm font-bold"><span>Donation Goal</span><span>KSh 45,000 of 100,000</span></div><div className="h-4 bg-white/15 rounded-full overflow-hidden mt-3"><div className="h-full bg-[#FFC107] rounded-full" style={{width:'45%'}}/></div><p className="text-[13px] text-white/75 mt-2">45% raised • KSh 55,000 to go. Balls • Kits • Transport • Lunch.</p></div></div>
      </div>
    </section>
  </div>;

  return (
    <div data-safe-area-inset-root style={{boxSizing:'border-box', paddingTop:'var(--safe-area-inset-top)'}} className="min-h-screen bg-[var(--bg)] text-[var(--text)] overflow-x-clip">
      <header data-safe-area-sticky-top style={{top:'var(--safe-area-inset-top)'}} className="sticky z-40 bg-[#06150c]/95 backdrop-blur border-b border-[var(--line)]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pt-4 pb-3">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <button onClick={()=>go('Home')} className="flex gap-3 items-center min-w-0 text-left">
              <div className="w-12 h-12 rounded-2xl bg-[#0A5C36] border-2 border-[#FFC107] grid place-items-center shrink-0 font-black text-[#FFC107] text-[15px]">CJS</div>
              <div className="min-w-0"><div className="flex items-center gap-2 flex-wrap"><h1 className="text-[clamp(19px,3.2vw,28px)] leading-none font-black tracking-tight">Chebukwabi JS <span className="text-[#FFC107]">Football</span></h1><span className="text-[10px] mono font-bold bg-[#FFC107] text-black px-2 py-1 rounded-full">BUNGOMA • KENYA</span></div><p className="text-[12px] text-[var(--muted)] mt-1">Pride of Chebukwabi | Discipline • Teamwork • Excellence</p></div>
            </button>
            <div className="flex items-center gap-2">
              <button onClick={()=>setLang(lang==='en'?'sw':'en')} className="min-h-[44px] px-3 rounded-full bg-[#122a1b] border border-[var(--line)] font-bold text-sm flex items-center gap-1.5"><Languages size={16}/> {lang==='en'?'EN • SW':'SW • EN'}</button>
              <button onClick={()=>openPortal(null)} className="min-h-[44px] px-4 rounded-full bg-white text-black font-black text-sm">Portal →</button>
            </div>
          </div>
          <nav className="flex gap-2 mt-4 overflow-x-auto scroll-row pb-1 -mx-1 px-1" aria-label="Top navigation">
            {nav.map(n=> <button key={n.key} onClick={()=>go(n.key)} className={`min-h-[48px] shrink-0 px-4 rounded-full text-[14px] font-bold border transition ${section===n.key ? 'bg-[#FFC107] text-black border-[#FFC107]' : 'bg-[#122a1b] border-[var(--line)] text-[var(--muted)] hover:text-white'}`}>{n.label}</button>)}
          </nav>
        </div>
      </header>

      <main className="max-w-[1280px] mx-auto px-4 sm:px-6 py-5 pb-10">
        {loadError && <div className="mb-4 rounded-2xl border border-[#FFC107]/40 bg-[#2a2105] p-4 text-sm">Saved squad, notes, join requests and attendance could not be loaded yet. The sample Chebukwabi JS data below is still available. <span className="text-[var(--muted)]">{loadError}</span></div>}
        <p className="text-center text-[12px] text-[var(--muted)] mb-4">Open in any browser • No install • No login • Works on phone, tablet & computer • Fungua kwa kivinjari chochote • Karibu!</p>

        {section==='Home' && <div>
          <section className="rounded-[28px] overflow-hidden bg-[#0A5C36] border-2 border-[#FFC107] p-5 sm:p-8 relative">
            <div className="grid lg:grid-cols-[1fr_260px] gap-6 items-center">
              <div>
                <span className="inline-flex items-center gap-2 bg-[#FFC107] text-black text-[11px] font-black px-3 py-1.5 rounded-full"><Trophy size={13}/> CHEBUKWABI JUNIOR SECONDARY • BUNGOMA COUNTY, KENYA</span>
                <h2 className="text-[clamp(34px,7vw,64px)] font-black leading-[0.92] mt-4 text-white">Chebukwabi JS<br/><span className="text-[#FFC107]">Football</span></h2>
                <p className="text-white/90 text-[16px] sm:text-[18px] font-semibold mt-3 max-w-[560px] leading-relaxed">Pride of Chebukwabi, Bungoma County, Kenya. {t.tagline}</p>
                <p className="text-white/75 text-[14px] mt-2 max-w-[560px]">A school team for everyone in Kenya — boys and girls together. Follow fixtures, meet the players, and join the team — right from your phone.</p>
                <div className="flex flex-wrap gap-2 mt-5">
                  <button onClick={()=>go('Join')} className="min-h-[56px] px-6 rounded-full bg-[#FFC107] text-black font-black text-[15px] flex items-center gap-2">{t.joinTeam} <ArrowRight size={17}/></button>
                  <button onClick={()=>go('Donate')} className="min-h-[56px] px-6 rounded-full bg-white text-[#0A5C36] font-black text-[15px] flex items-center gap-2"><Coins size={17}/> Donate • Changia</button>
                  <button onClick={()=>openPortal(null)} className="min-h-[56px] px-6 rounded-full bg-black/30 border-2 border-white text-white font-black text-[15px]">{t.enterPortal} →</button>
                </div>
                <div className="flex flex-wrap gap-2 mt-4 text-[12px] font-bold text-white"><span className="bg-black/25 px-3 py-1.5 rounded-full">✓ No install</span><span className="bg-black/25 px-3 py-1.5 rounded-full">✓ No login</span><span className="bg-black/25 px-3 py-1.5 rounded-full">✓ Low data • Fast</span><span className="bg-black/25 px-3 py-1.5 rounded-full">✓ Boys + Girls</span></div>
              </div>
              <div className="bg-[#FFC107] rounded-[22px] p-5 text-black text-center"><div className="w-[92px] h-[92px] mx-auto rounded-full bg-[#0A5C36] text-[#FFC107] grid place-items-center font-black text-[30px] border-4 border-white">CJS</div><p className="font-black text-lg mt-3 leading-tight">Green & Gold<br/>Badge</p><p className="text-[13px] font-medium mt-1">Chebukwabi JS<br/>Bungoma County, Kenya</p><div className="grid grid-cols-3 gap-2 mt-4 text-center"><div className="bg-black/10 rounded-xl py-2"><b>36</b><div className="text-[10px] font-bold">PLAYERS</div></div><div className="bg-black/10 rounded-xl py-2"><b>2</b><div className="text-[10px] font-bold">TEAMS</div></div><div className="bg-black/10 rounded-xl py-2"><b>2nd</b><div className="text-[10px] font-bold">LEAGUE</div></div></div></div>
            </div>
          </section>
          <div className="mt-4"><h3 className="font-black text-lg mb-2">{t.stats} • Takwimu za Msimu</h3>{seasonStats}</div>
          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <section className="bg-[#FFC107] text-black rounded-[24px] p-5"><p className="mono text-[11px] font-bold tracking-widest flex items-center gap-2"><CalendarDays size={14}/> {t.next.toUpperCase()} • MECHI IJAYO</p><h3 className="font-black text-[26px] leading-tight mt-2">vs {nextMatch.opp}</h3><p className="text-[13px] font-semibold opacity-80 mt-1 flex items-center gap-1"><MapPin size={14}/> {nextMatch.venue} • {nextMatch.date}</p><p className="text-[13px] font-medium mt-2 leading-relaxed">{nextMatch.comp}. {nextMatch.note}</p><button onClick={()=>go('Fixtures')} className="min-h-[48px] mt-4 px-5 rounded-full bg-black text-white font-bold text-sm">View Fixtures →</button></section>
            <section className="bg-white text-[#0a1a10] rounded-[24px] p-5 border border-[#d7e5da]"><p className="mono text-[11px] font-bold tracking-widest flex items-center gap-2 text-[#0A5C36]"><CheckCircle2 size={14}/> {t.last.toUpperCase()} • MATOKEO YA MWISHO</p><h3 className="font-black text-[26px] leading-tight mt-2">Chebukwabi JS {lastResult.score} <span className="text-[#0A5C36]">{lastResult.opp}</span></h3><p className="text-[13px] text-[#4a5a50] mt-1">{lastResult.comp} • Scorers: {lastResult.scorers}</p><p className="text-[13px] mt-2 leading-relaxed">{lastResult.note}</p><button onClick={()=>go('Fixtures')} className="min-h-[48px] mt-4 px-5 rounded-full bg-[#0A5C36] text-white font-bold text-sm">All Results →</button></section>
          </div>
          <section className="grid lg:grid-cols-2 gap-4 mt-6">
            <div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">{t.about.toUpperCase()}</p><h3 className="font-black text-[26px] leading-tight mt-1">A school team from Bungoma County, Kenya.</h3><p className="text-[14px] text-[var(--muted)] leading-relaxed mt-2">Chebukwabi JS is the football team of Chebukwabi Junior Secondary. Our players come from Grades 7, 8 and 9 — boys and girls, equally supported. We play in the Sub-County School Games and we are proud to represent our school and our community.</p><p className="text-[14px] text-[var(--muted)] leading-relaxed mt-2">Our mission: help every young player grow — on the pitch, in class, and in life. Football teaches discipline, respect, and teamwork.</p></div>
            <div className="grid grid-cols-1 min-[480px]:grid-cols-3 gap-3">
              {[{icon:'🎯', title:'Discipline', sw:'Nidhamu', body:'Arrive early. Listen. Work hard.'},{icon:'🤝', title:'Teamwork', sw:'Kazi ya Timu', body:'We win together. We lose together.'},{icon:'⭐', title:'Excellence', sw:'Ubora', body:'Give your best every session.'}].map(v=> <div key={v.title} className="bg-white text-[#0a1a10] rounded-[22px] p-4 border border-[#d7e5da] min-w-0"><span className="text-[28px]">{v.icon}</span><h4 className="font-black mt-2 leading-tight text-[clamp(15px,4vw,18px)] break-words [overflow-wrap:anywhere]">{v.title}</h4><p className="text-[12px] font-bold text-[#0A5C36]">{v.sw}</p><p className="text-[13px] text-[#4a5a50] mt-1 leading-relaxed">{v.body}</p></div>)}
            </div>
          </section>
          <div className="grid md:grid-cols-2 gap-4 mt-6">
            <section className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black text-xl">Boys Team • Coach Galvin</h3><p className="text-[13px] text-[var(--muted)] mt-1">Captain: Ian Wanjala • Top scorer: Emmanuel Khaemba</p><div className="flex flex-wrap gap-2 mt-3">{players.slice(0,6).map(p=> <span key={p.id} className="bg-[#0a1a10] rounded-full px-3 py-1.5 text-[13px]">#{p.num} {p.name}</span>)}</div><button onClick={()=>go('Boys')} className="min-h-[48px] mt-4 px-5 rounded-full bg-[#FFC107] text-black font-black text-sm">See Boys Squad →</button></section>
            <section className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black text-xl">Girls Team • Coach Mary</h3><p className="text-[13px] text-[var(--muted)] mt-1">Captain: Grace Wanjiru • Top scorer: Faith Chebet</p><div className="flex flex-wrap gap-2 mt-3">{girlsPlayers.slice(0,6).map(p=> <span key={p.id} className="bg-[#0a1a10] rounded-full px-3 py-1.5 text-[13px]">#{p.num} {p.name}</span>)}</div><button onClick={()=>go('Girls')} className="min-h-[48px] mt-4 px-5 rounded-full bg-[#FFC107] text-black font-black text-sm">See Girls Squad →</button></section>
          </div>
          <div className="mt-6"><h3 className="font-black text-[26px] leading-tight mb-3">Upcoming Fixtures — Boys & Girls</h3>{fixturesTwoCol}</div>
          <div className="mt-6 bg-[#f2f7f2] rounded-[28px] p-4 sm:p-6"><div className="flex justify-between items-end mb-3"><div><p className="mono text-[11px] tracking-[0.2em] text-[#0A5C36]">{t.latest.toUpperCase()} • HABARI</p><h3 className="font-black text-[26px] leading-tight text-[#0a1a10]">What is happening?</h3></div><button onClick={()=>go('News')} className="min-h-[44px] px-4 rounded-full bg-[#0A5C36] text-white font-bold text-sm">All News →</button></div>{newsCards}</div>
          <div className="mt-6"><div className="flex justify-between items-end mb-3"><div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">{t.gallery.toUpperCase()}</p><h3 className="font-black text-[26px] leading-tight">Green & Gold Gallery</h3></div><button onClick={()=>openPortal('Parent','Team Photos')} className="min-h-[44px] px-4 rounded-full bg-[#122a1b] border border-[var(--line)] font-bold text-sm">Team Photos →</button></div>{galleryStrip}<p className="text-[12px] text-[var(--muted)] mt-2">Colour blocks in team colours — photo uploads are not available yet.</p></div>
          <div className="grid lg:grid-cols-2 gap-4 mt-6 items-start"><div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black text-[24px] leading-tight">{t.contact}</h3><p className="text-[14px] text-[var(--muted)] mt-2 leading-relaxed">Chebukwabi JS • Bungoma County, Kenya<br/>Come to training at Chebukwabi JS Ground — Mon / Wed / Fri, 4:00 PM.<br/>Parents and fans are always welcome.</p><div className="flex flex-wrap gap-2 mt-4"><span className="flex items-center gap-1.5 bg-[#0a1a10] rounded-full px-3 py-2 text-[13px] font-bold"><MapPin size={14}/> Chebukwabi JS Ground</span><span className="flex items-center gap-1.5 bg-[#0a1a10] rounded-full px-3 py-2 text-[13px] font-bold"><Phone size={14}/> Ask at school office</span><span className="flex items-center gap-1.5 bg-[#0a1a10] rounded-full px-3 py-2 text-[13px] font-bold"><Mail size={14}/> Via school office</span></div><div className="bg-[#FFC107] text-black rounded-2xl p-4 mt-4"><p className="font-black flex items-center gap-2"><Heart size={16}/> For parents & fans</p><p className="text-[13px] font-medium mt-1">Open the Portal, choose Parent / Fan, and see fixtures, league table and top scorers. No login needed.</p><button onClick={()=>openPortal('Parent')} className="min-h-[48px] mt-3 px-5 rounded-full bg-black text-white font-bold text-sm">Open Parent / Fan Portal →</button></div></div><JoinForm compact /></div>
        </div>}

        {section==='Boys' && <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">BOYS TEAM • TIMU YA WAVULANA</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Boys Team • Wavulana</h2><p className="text-[14px] text-[var(--muted)] mt-2">Chebukwabi JS Boys • Coach Galvin • Captain: Ian Wanjala • Grades 7, 8 and 9.</p><div className="mt-4">{SquadBlock({teamKey:'Boys', list:players, selected:selectedPlayer, onSelect:setSelectedPlayer, tab:boysTab, setTab:setBoysTab})}</div></div>}
        {section==='Girls' && <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">GIRLS TEAM • TIMU YA WASICHANA</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Girls Team • Wasichana</h2><p className="text-[14px] text-[var(--muted)] mt-2">Chebukwabi JS Girls • Coach Mary • Captain: Grace Wanjiru • Grades 7, 8 and 9. Equally prominent, equally supported.</p><div className="mt-4">{SquadBlock({teamKey:'Girls', list:girlsPlayers, selected:selectedGirl, onSelect:setSelectedGirl, tab:girlsTab, setTab:setGirlsTab})}</div></div>}

        {section==='Fixtures' && <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">FIXTURES • MECHI ZIJAZO</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Upcoming Fixtures</h2><p className="text-[14px] text-[var(--muted)] mt-2">Bungoma Sub-County Games & Friendlies • Boys and Girls side by side.</p><div className="mt-4">{fixturesTwoCol}</div><div className="mt-5"><h3 className="font-black mb-2">Boys — recent results</h3>{matchCardList(boysMatches)}</div><div className="mt-4"><h3 className="font-black mb-2">Girls — recent results</h3>{matchCardList(girlsMatches)}</div></div>}

        {section==='Tactical' && <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">TACTICAL BOARD • BODI YA MBINU</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Tactical Board — Inbuilt App</h2><p className="text-[14px] text-[var(--muted)] mt-2">Drag players on the pitch. Works on touch, phone, tablet and computer.</p><div className="mt-4">{tacticsBlock}</div></div>}

        {section==='Analysis' && <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">POST-MATCH ANALYSIS • UCHAMBUZI</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Post-Match Analysis</h2><p className="text-[14px] text-[var(--muted)] mt-2">Pick a boys or girls match to see the full story — stats, momentum, moments and the coach verdict.</p><div className="mt-4">{analysisBlock}</div></div>}

        {section==='News' && <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">{t.news.toUpperCase()} • HABARI</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">Team News</h2><div className="mt-4 bg-[#f2f7f2] rounded-[28px] p-4 sm:p-6">{newsCards}</div><div className="mt-4 bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5"><h3 className="font-black flex items-center gap-2"><Megaphone size={18} className="text-[#FFC107]"/> {t.announcements}</h3><div className="grid sm:grid-cols-2 gap-3 mt-3">{[...starterNotes, ...savedNotes.map(n=>({kind:n.kind, title:n.title, body:n.body}))].map((n,i)=> <div key={i} className="bg-[#0a1a10] rounded-2xl p-4"><span className="mono text-[11px] text-[#FFC107] font-bold">{n.kind.toUpperCase()}</span><h4 className="font-black mt-1 leading-tight">{n.title}</h4><p className="text-[13px] text-[var(--muted)] leading-relaxed mt-1">{n.body}</p></div>)}</div></div></div>}

        {section==='Join' && <div className="grid lg:grid-cols-2 gap-4 items-start">
          <div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">JOIN US • JIUNGE NASI</p><h2 className="text-[clamp(28px,5vw,44px)] font-black leading-none mt-1">Join The Team.<br/><span className="text-[#FFC107]">Jiunge na Timu.</span></h2><p className="text-[15px] text-[var(--muted)] mt-3 leading-relaxed">Open to Grades 7, 8 and 9 — boys and girls. No experience needed — discipline and teamwork first. Fill the form and the coach will see your request.</p><div className="bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 mt-4"><h3 className="font-black flex items-center gap-2"><ClipboardCheck size={18} className="text-[#FFC107]"/> What happens next?</h3><ol className="text-[14px] text-[var(--muted)] leading-relaxed mt-2 space-y-2 list-decimal pl-5"><li>Fill the form — name, gender, class, position, phone, guardian phone.</li><li>Your request is saved for the coach.</li><li>Come to training — Mon / Wed / Fri, 4:00 PM, Chebukwabi JS Ground.</li><li>Trials are friendly. Bring boots and water.</li></ol></div><div className="bg-white text-[#0a1a10] rounded-[24px] p-5 mt-4"><h3 className="font-black">Contact</h3><p className="text-[14px] text-[#4a5a50] mt-1">Chebukwabi JS • Bungoma County, Kenya<br/>Chebukwabi JS Ground • Ask at the school office</p></div></div>
          <JoinForm />
        </div>}

        {section==='Donate' && donateBlock}

        {section==='Portal' && <div>
          {!role ? <div>
            <p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">TEAM PORTAL • PORTAL YA TIMU</p><h2 className="text-[clamp(28px,5vw,44px)] font-black leading-none mt-1">{t.welcome}</h2><p className="text-[15px] text-[var(--muted)] mt-2 max-w-[640px]">{t.choose} Tap your role below. No password. No account. / Bonyeza jukumu lako hapa chini. Hakuna neno la siri.</p>
            <div className="grid sm:grid-cols-3 gap-4 mt-5">
              {[{r:'Coach' as Role, icon:'🧑‍🏫', title:t.coach, desc:'Squad management • Attendance • Notes • Dashboard', color:'#0A5C36'},{r:'Player' as Role, icon:'⚽', title:t.player, desc:'My Profile • My Stats • Training • Announcements', color:'#FFC107'},{r:'Parent' as Role, icon:'👨‍👩‍👧', title:t.parent, desc:'Fixtures • News • Photos • Results', color:'#ffffff'}].map(c=> <button key={String(c.r)} onClick={()=>openPortal(c.r, c.r==='Coach'?'Dashboard':c.r==='Player'?'My Profile':'Fixtures')} className="text-left bg-[var(--surface)] border border-[var(--line)] rounded-[24px] p-5 hover:border-[#FFC107] min-h-[220px] flex flex-col"><span className="text-[44px]">{c.icon}</span><h3 className="font-black text-[24px] mt-3">{c.title}</h3><p className="text-[14px] text-[var(--muted)] mt-1 flex-1">{c.desc}</p><span className="mt-4 min-h-[48px] rounded-full bg-[#FFC107] text-black font-black text-sm grid place-items-center">Open {c.title} →</span></button>)}
            </div>
            <div className="bg-white text-[#0a1a10] rounded-[24px] p-5 mt-4"><h3 className="font-black">Why no login?</h3><p className="text-[14px] text-[#4a5a50] mt-1 leading-relaxed">So anyone in Kenya can open it in any browser — Chrome, Safari, Opera Mini — without an account or install. Choose a role and start.</p></div>
          </div> : <div>
            <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="mono text-[11px] tracking-[0.2em] text-[var(--accent)]">{role?.toUpperCase()} PORTAL</p><h2 className="text-[clamp(26px,4vw,38px)] font-black leading-none mt-1">{role==='Coach'?'Coach Dashboard':role==='Player'?'Player Dashboard':'Parent / Fan Dashboard'}</h2></div><button onClick={()=>setRole(null)} className="min-h-[48px] px-5 rounded-full bg-[#122a1b] border border-[var(--line)] font-bold text-sm">← Change Role / Badilisha Jukumu</button></div>
            <nav className="flex gap-2 mt-4 overflow-x-auto scroll-row pb-1" aria-label="Portal tabs">
              {(role==='Coach'?coachTabs:role==='Player'?playerTabs:parentTabs).map(tab=> <button key={tab} onClick={()=>setPortalTab(tab)} className={`min-h-[48px] shrink-0 px-4 rounded-full text-[14px] font-bold border ${portalTab===tab?'bg-[#FFC107] text-black border-[#FFC107]':'bg-[#122a1b] border-[var(--line)] text-[var(--muted)]'}`}>{tab}</button>)}
            </nav>
            <div className="mt-5">
              {role==='Coach' && portalTab==='Dashboard' && dashboardBlock}
              {role==='Coach' && portalTab==='Squad' && playersBlock}
              {role==='Coach' && portalTab==='Attendance' && attendanceBlock}
              {role==='Coach' && portalTab==='Notes' && notesBlock}
              {role==='Player' && portalTab==='My Profile' && myProfileBlock}
              {role==='Player' && portalTab==='Training' && <div><h3 className="font-black text-[24px]">{t.training}</h3><div className="grid sm:grid-cols-2 gap-3 mt-3">{trainingSchedule.map((s,i)=> <div key={i} className="bg-[var(--surface)] border border-[var(--line)] rounded-[22px] p-4"><span className="mono text-[11px] text-[#FFC107] font-bold">{(lang==='sw'?s.daySw:s.day).toUpperCase()} • {s.time}</span><h4 className="font-black mt-1">{lang==='sw'?s.focusSw:s.focus}</h4><p className="text-[13px] text-[var(--muted)] mt-1">Chebukwabi JS Ground • Arrive 15 minutes early.</p></div>)}</div><div className="mt-4">{matchCardList([...boysMatches, ...girlsMatches])}</div></div>}
              {role==='Player' && portalTab==='Announcements' && <div><h3 className="font-black text-[24px]">{t.announcements}</h3><div className="grid sm:grid-cols-2 gap-3 mt-3">{[...starterNotes, ...savedNotes.map(n=>({kind:n.kind, title:n.title, body:n.body}))].map((n,i)=> <div key={i} className="bg-[var(--surface)] border border-[var(--line)] rounded-[22px] p-4"><span className="mono text-[11px] text-[#FFC107] font-bold">{n.kind.toUpperCase()}</span><h4 className="font-black mt-1">{n.title}</h4><p className="text-[13px] text-[var(--muted)] mt-1 leading-relaxed">{n.body}</p></div>)}</div></div>}
              {role==='Parent' && portalTab==='Fixtures' && <div><h3 className="font-black text-[24px]">{t.fixtures}</h3><div className="mt-3">{fixturesTwoCol}</div><div className="mt-4 bg-white text-[#0a1a10] rounded-[24px] p-4 overflow-x-auto"><h4 className="font-black mb-2">{t.league}</h4><table className="w-full min-w-[520px] text-[14px]"><thead><tr className="text-left text-[11px] text-[#5a6a60]"><th className="py-2">#</th><th>TEAM</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>PTS</th></tr></thead><tbody>{leagueTable.map((row,i)=> <tr key={row.team} className={`border-t border-[#e2ece4] ${row.team==='Chebukwabi JS'?'bg-[#fff3c4] font-black':''}`}><td className="py-3">{i+1}</td><td>{row.team}</td><td>{row.p}</td><td>{row.w}</td><td>{row.d}</td><td>{row.l}</td><td>{row.gf}</td><td>{row.ga}</td><td>{row.pts}</td></tr>)}</tbody></table></div></div>}
              {role==='Parent' && portalTab==='News' && <div><h3 className="font-black text-[24px]">{t.news}</h3><div className="mt-3 bg-[#f2f7f2] rounded-[28px] p-4">{newsCards}</div></div>}
              {role==='Parent' && portalTab==='Team Photos' && <div><h3 className="font-black text-[24px]">{t.photos}</h3><p className="text-[14px] text-[var(--muted)] mt-1">Team colours and moments. Photo uploads are not available yet.</p><div className="mt-3">{galleryStrip}</div><div className="grid sm:grid-cols-2 gap-3 mt-3"><div className="bg-[#0A5C36] text-white rounded-[22px] p-5"><h4 className="font-black">Match Day • Siku ya Mechi</h4><p className="text-[13px] text-white/80 mt-1">Saturday • 10:00 AM • Chebukwabi JS Ground. Come in green and gold.</p></div><div className="bg-[#FFC107] text-black rounded-[22px] p-5"><h4 className="font-black">Training • Mazoezi</h4><p className="text-[13px] font-medium mt-1">Mon / Wed / Fri • 4:00 PM. Boots, water, discipline.</p></div></div></div>}
            </div>
          </div>}
        </div>}
      </main>
      <footer className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-8 text-center">
        <div className="bg-[#0A5C36] border border-[#FFC107]/40 rounded-[24px] p-5"><div className="flex items-center justify-center gap-2"><span className="w-10 h-10 rounded-xl bg-[#FFC107] text-black grid place-items-center font-black">CJS</span><b className="text-[18px]">Chebukwabi JS</b></div><p className="text-[13px] text-white/80 mt-2">Bungoma, Kenya • Discipline • Teamwork • Excellence • Karibu • Asante</p><p className="text-[13px] font-bold text-[#FFC107] mt-1">Pochi La Biashara: 0724711658 • Chebukwabi JS</p><p className="text-[13px] font-bold text-[#FFC107] mt-1">Made for Kenya — works on any browser • Imetengenezwa kwa Kenya</p><div className="flex justify-center gap-2 mt-3 flex-wrap">{nav.map(n=> <button key={n.key} onClick={()=>go(n.key)} className="min-h-[40px] px-3 rounded-full bg-white/10 text-[13px] font-bold">{n.label}</button>)}</div><button onClick={()=>go('Join')} className="mt-3 min-h-[48px] px-6 rounded-full bg-[#FFC107] text-black font-black text-sm">Join Us • Jiunge Nasi →</button></div>
        <p className="text-[12px] text-[var(--muted)] mt-3">Chebukwabi JS • Home of Chebukwabi JS Football • Boys & Girls • Bungoma County, Kenya.</p>
      </footer>
    </div>
  );
}

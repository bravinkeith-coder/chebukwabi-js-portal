# Chebukwabi JS Football Portal — Netlify Edition

A complete football portal for **Chebukwabi JS Boys and Girls teams**, upgraded from the supplied portal source. It retains the forest-green and gold visual identity, Archivo / JetBrains Mono typography, football pitch styling and the original portal's football-management direction.

## Included features

### Public website
- Home dashboard and club statistics
- Boys and Girls squad profiles
- Fixtures and results
- Live Match Centre with automatic refresh every 8 seconds
- Match event timeline
- Tactical board: 4-3-3, 4-2-3-1, 4-4-2 and 3-5-2
- Attacking and defensive shape views
- Coaching and match-analysis framework
- News and announcements

### Admin-only management
- Password-protected administrator sign-in
- Create and manage fixtures
- Start live matches, mark full time or postpone
- Publish goals, cards, substitutions and match events
- Correct match scores
- Register and remove players, with duplicate shirt-number prevention per team
- Record Boys/Girls training attendance by date and session
- Re-saving the same player's attendance for the same date/session updates the record
- Publish announcements and match reports

### Data and security
- Netlify Functions provide server-side API routes
- Netlify Blobs stores portal records persistently
- Administrator password and session secret are server-side environment variables
- Signed, HttpOnly, Secure, SameSite session cookie with an eight-hour expiry
- Public visitors cannot write portal records
- No invented sample scores or players are preloaded

**Live scoring note:** this is administrator-operated live scoring. An authorised administrator records match events during the game; supporters see saved changes refresh automatically. It is not connected to an official external football data feed.

## Important: deploy the ZIP correctly

The ZIP includes Netlify Functions. A plain static drag-and-drop upload may publish the website files but may not build/deploy the Functions. Use the GitHub-connected Netlify deployment below so that the API and persistent data features work.

## Deploy using GitHub and Netlify

1. Extract this ZIP on your computer.
2. Sign in to GitHub. Create a new repository, for example `chebukwabi-js-portal`. Public is fine.
3. Open the new repository and choose **Add file → Upload files**.
4. Upload the *contents* of the extracted folder (not the ZIP file itself). Ensure `netlify.toml`, `package.json` and the `netlify` folder are at the repository root. The website files are already inside `public`.
5. Commit the files.
6. Sign in to Netlify and choose **Add new site → Import an existing project**.
7. Connect GitHub and select `chebukwabi-js-portal`.
8. In the deploy settings, use:
   - Build command: leave blank (or `echo "Static site; Netlify Functions are bundled automatically"`)
   - Publish directory: `public`
   - Functions directory: `netlify/functions`
9. Deploy the site.

## Set administrator secrets

After the first deployment:

1. In Netlify, open your site.
2. Go to **Site configuration → Environment variables** (or **Project configuration → Environment variables**, depending on the dashboard).
3. Add `ADMIN_PASSWORD` with a strong, unique administrator password.
4. Add `SESSION_SECRET` with a different random secret of at least 32 characters.
5. Set the scope to include **Functions** / all deploy contexts.
6. Save the variables and trigger **Deploys → Trigger deploy → Deploy site**.

Do not put real passwords in `app.js`, `index.html`, GitHub, or this README. Do not share the administrator password with players or supporters.

## First-use test

1. Open your public Netlify URL. Home, squads, fixtures, tactical board and news should load.
2. Select **Admin Login** and sign in using the `ADMIN_PASSWORD` environment variable.
3. In **Squad**, register a Boys or Girls player.
4. In **Fixtures**, create a fixture.
5. Change its status to **Start live**.
6. In **Live Match**, select the fixture and publish a goal for the home or away team.
7. Open the public Match Centre in another browser/device. The score and event should appear within about eight seconds.
8. Record attendance and publish a news announcement to test the remaining tools.

## Notes for Windows 32-bit users

You can create the GitHub repository and upload the extracted project files through the browser. You do not need to install Node.js just to upload the project to GitHub or connect Netlify. Netlify builds and bundles the serverless function in its cloud deployment environment.

## Data persistence

Records are stored in Netlify Blobs, not only in a visitor's browser. They remain available after refreshing the site and across visitors/devices. Keep access to the Netlify account secure. For important club records, periodically export/backup the site's stored data using a future backup workflow or Netlify's available storage tooling.

## Supplied-source note

The supplied archive contained `App.tsx`, `index.css` and a VFS manifest, but no original package configuration, server/API implementation or database. This deployable project retains the original green/gold design language and football portal purpose while implementing the missing Netlify backend and deployment structure.

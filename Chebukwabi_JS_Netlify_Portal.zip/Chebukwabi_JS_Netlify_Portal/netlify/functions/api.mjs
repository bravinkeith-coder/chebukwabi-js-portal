import { getStore } from "@netlify/blobs";
import { createHmac, timingSafeEqual, randomUUID } from "node:crypto";

const STORE = "chebukwabi-js-portal";
const empty = { fixtures: [], players: [], news: [], attendance: [], events: [] };
const json = (body, status=200, headers={}) => new Response(JSON.stringify(body), {
  status, headers: { "content-type":"application/json; charset=utf-8", "cache-control":"no-store", ...headers }
});
const fail = (message,status=400) => json({error:message},status);
const secret = () => process.env.SESSION_SECRET || "";
const sign = value => createHmac("sha256", secret()).update(value).digest("base64url");
const cookieName = "cjs_admin";
function readCookie(req) {
  const raw=req.headers.get("cookie")||"";
  const found=raw.split(";").map(x=>x.trim()).find(x=>x.startsWith(cookieName+"="));
  return found ? decodeURIComponent(found.slice(cookieName.length+1)) : "";
}
function isAdmin(req) {
  if(!secret()) return false;
  const token=readCookie(req), parts=token.split(".");
  if(parts.length!==2) return false;
  const [payload,signature]=parts, expected=sign(payload);
  const a=Buffer.from(signature), b=Buffer.from(expected);
  if(a.length!==b.length || !timingSafeEqual(a,b)) return false;
  try { return JSON.parse(Buffer.from(payload,"base64url").toString()).exp>Date.now(); } catch { return false; }
}
async function readData(store) {
  return (await store.get("portal-data",{type:"json"})) || structuredClone(empty);
}
async function writeData(store,data) { await store.setJSON("portal-data",data); }
const safeText=(v,max=500)=>String(v??"").trim().slice(0,max);
export default async (req) => {
  const url=new URL(req.url);
  const path=(url.searchParams.get("path")||url.pathname.split("/").pop()||"").replace(/^\/+/,"");
  const store=getStore({name:STORE,consistency:"strong"});
  if(req.method==="GET" && path==="public") {
    const d=await readData(store);
    return json({fixtures:d.fixtures,players:d.players.filter(p=>p.active!==false),news:d.news,events:d.events});
  }
  if(req.method==="GET" && path==="session") return json({authenticated:isAdmin(req)});
  if(req.method==="POST" && path==="login") {
    const body=await req.json().catch(()=>null);
    if(!process.env.ADMIN_PASSWORD || !secret()) return fail("Administrator secrets are not configured in Netlify.",503);
    const supplied=String(body?.password||"");
    const a=Buffer.from(supplied), b=Buffer.from(process.env.ADMIN_PASSWORD);
    if(a.length!==b.length || !timingSafeEqual(a,b)) return fail("Incorrect administrator password.",401);
    const payload=Buffer.from(JSON.stringify({exp:Date.now()+8*60*60*1000,nonce:randomUUID()})).toString("base64url");
    const token=payload+"."+sign(payload);
    return json({ok:true},200,{ "set-cookie":`${cookieName}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800` });
  }
  if(req.method==="POST" && path==="logout") return json({ok:true},200,{"set-cookie":`${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`});
  if(!path.startsWith("admin/")) return fail("Not found.",404);
  if(!isAdmin(req)) return fail("Administrator session expired. Sign in again.",401);
  if(req.method!=="POST") return fail("Method not allowed.",405);
  const body=await req.json().catch(()=>null);
  if(!body) return fail("Invalid request body.");
  const d=await readData(store), now=new Date().toISOString();
  const ok=()=>writeData(store,d).then(()=>json({ok:true}));
  switch(path) {
    case "admin/fixtures": {
      const home=safeText(body.home,80), away=safeText(body.away,80), date=safeText(body.date,20);
      if(!home||!away||!date) return fail("Home team, away team and date are required.");
      d.fixtures.push({id:randomUUID(),team:body.team==="Girls"?"Girls":"Boys",home,away,date,time:safeText(body.time,10),venue:safeText(body.venue,100),competition:safeText(body.competition,80)||"Friendly",status:"SCHEDULED",homeScore:0,awayScore:0,events:[],createdAt:now,updatedAt:now});
      break;
    }
    case "admin/fixture-status": {
      const f=d.fixtures.find(x=>x.id===body.id); if(!f)return fail("Fixture not found.",404);
      if(!["SCHEDULED","LIVE","FT","POSTPONED"].includes(body.status))return fail("Invalid fixture status.");
      f.status=body.status;f.updatedAt=now;break;
    }
    case "admin/score": {
      const f=d.fixtures.find(x=>x.id===body.id);if(!f)return fail("Fixture not found.",404);
      const h=Number(body.homeScore),a=Number(body.awayScore);
      if(!Number.isInteger(h)||!Number.isInteger(a)||h<0||a<0)return fail("Scores must be non-negative whole numbers.");
      f.homeScore=h;f.awayScore=a;f.updatedAt=now;break;
    }
    case "admin/event": {
      const f=d.fixtures.find(x=>x.id===body.fixtureId);if(!f)return fail("Fixture not found.",404);
      if(f.status!=="LIVE")return fail("Start the match before adding live events.",409);
      const type=safeText(body.type,30), side=body.side==="away"?"away":"home";
      const ev={id:randomUUID(),fixtureId:f.id,type,side,player:safeText(body.player,80),minute:safeText(body.minute,8),createdAt:now};
      d.events.unshift(ev);
      if(type==="Goal") { if(side==="home")f.homeScore++;else f.awayScore++; }
      if(type==="Full-time")f.status="FT";
      f.updatedAt=now;break;
    }
    case "admin/player": {
      const name=safeText(body.name,100),number=Number(body.number);
      if(!name||!Number.isInteger(number)||number<1||number>99)return fail("Enter a player name and shirt number (1–99).");
      const team=body.team==="Girls"?"Girls":"Boys";
      if(d.players.some(p=>p.active!==false&&p.team===team&&p.number===number))return fail("That shirt number is already registered for this team.");
      d.players.push({id:randomUUID(),team,name,number,position:safeText(body.position,8)||"MF",grade:safeText(body.grade,30),active:true,createdAt:now});break;
    }
    case "admin/delete-player": {
      const p=d.players.find(x=>x.id===body.id);if(!p)return fail("Player not found.",404);p.active=false;break;
    }
    case "admin/news": {
      const title=safeText(body.title,140),content=safeText(body.body,5000);
      if(!title||!content)return fail("Headline and announcement are required.");
      d.news.unshift({id:randomUUID(),title,body:content,category:safeText(body.category,30)||"Announcement",createdAt:now});break;
    }
    case "admin/attendance": {
      const date=safeText(body.date,20),team=body.team==="Girls"?"Girls":"Boys",session=safeText(body.session,50)||"Training";
      if(!date||!Array.isArray(body.records))return fail("Attendance date and player records are required.");
      for(const r of body.records) {
        const player=d.players.find(p=>p.id===r.playerId&&p.active!==false);
        if(!player)continue;
        const existing=d.attendance.find(x=>x.playerId===player.id&&x.date===date&&x.session===session);
        const record={playerId:player.id,playerName:player.name,team,date,session,status:r.status==="Present"?"Present":"Absent"};
        if(existing)Object.assign(existing,record);else d.attendance.push({id:randomUUID(),...record});
      }
      break;
    }
    default:return fail("Unknown administrator action.",404);
  }
  await writeData(store,d);
  return json({ok:true});
};
